# TrustAI Database Models
# SQLAlchemy models for users, roles, AI decisions, explanations, consents, and audit logs

from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime, timezone
import json
import uuid

db = SQLAlchemy()

class User(UserMixin, db.Model):
    """User model for authentication and role management"""
    __tablename__ = 'users'
    
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    email = db.Column(db.String(120), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=False)
    first_name = db.Column(db.String(50), nullable=False)
    last_name = db.Column(db.String(50), nullable=False)
    role = db.Column(db.Enum('customer', 'customer_service', 'compliance_officer', 'admin', name='user_role'), nullable=False)
    department = db.Column(db.String(100))
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    last_login = db.Column(db.DateTime)
    
    # Relationships
    decisions = db.relationship('AIDecision', backref='user', lazy=True, cascade='all, delete-orphan')
    consents = db.relationship('Consent', backref='user', lazy=True, cascade='all, delete-orphan')
    audit_logs = db.relationship('AuditLog', backref='user', lazy=True, cascade='all, delete-orphan')
    
    def set_password(self, password):
        """Set password hash"""
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        """Check password against hash"""
        return check_password_hash(self.password_hash, password)
    
    def get_full_name(self):
        """Get user's full name"""
        return f"{self.first_name} {self.last_name}"
    
    def to_dict(self):
        """Convert user to dictionary"""
        return {
            'id': self.id,
            'email': self.email,
            'first_name': self.first_name,
            'last_name': self.last_name,
            'role': self.role,
            'department': self.department,
            'is_active': self.is_active,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'last_login': self.last_login.isoformat() if self.last_login else None
        }

class AIDecision(db.Model):
    """AI Decision model for tracking AI system decisions"""
    __tablename__ = 'ai_decisions'
    
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id = db.Column(db.String(36), db.ForeignKey('users.id'), nullable=False)
    decision_type = db.Column(db.String(50), nullable=False)  # e.g., 'loan_approval', 'credit_limit', 'risk_assessment'
    model_name = db.Column(db.String(100), nullable=False)
    model_version = db.Column(db.String(20), nullable=False)
    input_data = db.Column(db.Text)  # JSON string of input features
    outcome = db.Column(db.String(50), nullable=False)  # e.g., 'approved', 'rejected', 'modified'
    confidence_score = db.Column(db.Float, nullable=False)
    processing_time_ms = db.Column(db.Integer)
    decision_metadata = db.Column(db.Text)  # JSON string for additional metadata
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), nullable=False)
    
    # Relationships
    explanation = db.relationship('Explanation', backref='decision', uselist=False, cascade='all, delete-orphan')
    
    def set_input_data(self, data):
        """Set input data as JSON string"""
        self.input_data = json.dumps(data) if data else None
    
    def get_input_data(self):
        """Get input data as dictionary"""
        return json.loads(self.input_data) if self.input_data else {}
    
    def set_metadata(self, metadata):
        """Set metadata as JSON string"""
        self.decision_metadata = json.dumps(metadata) if metadata else None
    
    def get_metadata(self):
        """Get metadata as dictionary"""
        return json.loads(self.decision_metadata) if self.decision_metadata else {}
    
    def to_dict(self):
        """Convert decision to dictionary"""
        return {
            'id': self.id,
            'user_id': self.user_id,
            'decision_type': self.decision_type,
            'model_name': self.model_name,
            'model_version': self.model_version,
            'input_data': self.get_input_data(),
            'outcome': self.outcome,
            'confidence_score': self.confidence_score,
            'processing_time_ms': self.processing_time_ms,
            'metadata': self.get_metadata(),
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'explanation': self.explanation.to_dict() if self.explanation else None
        }

class Explanation(db.Model):
    """AI Explanation model for storing SHAP/LIME explanations"""
    __tablename__ = 'explanations'
    
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    decision_id = db.Column(db.String(36), db.ForeignKey('ai_decisions.id'), nullable=False)
    explanation_method = db.Column(db.String(20), nullable=False)  # 'shap', 'lime', 'native'
    feature_importance = db.Column(db.Text)  # JSON string of feature importance scores
    feature_values = db.Column(db.Text)  # JSON string of actual feature values
    base_value = db.Column(db.Float)  # Base prediction value
    explanation_text = db.Column(db.Text)  # Human-readable explanation
    fairness_metrics = db.Column(db.Text)  # JSON string of fairness metrics
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), nullable=False)
    
    def set_feature_importance(self, importance):
        """Set feature importance as JSON string"""
        self.feature_importance = json.dumps(importance) if importance else None
    
    def get_feature_importance(self):
        """Get feature importance as dictionary"""
        return json.loads(self.feature_importance) if self.feature_importance else {}
    
    def set_feature_values(self, values):
        """Set feature values as JSON string"""
        self.feature_values = json.dumps(values) if values else None
    
    def get_feature_values(self):
        """Get feature values as dictionary"""
        return json.loads(self.feature_values) if self.feature_values else {}
    
    def set_fairness_metrics(self, metrics):
        """Set fairness metrics as JSON string"""
        self.fairness_metrics = json.dumps(metrics) if metrics else None
    
    def get_fairness_metrics(self):
        """Get fairness metrics as dictionary"""
        return json.loads(self.fairness_metrics) if self.fairness_metrics else {}
    
    def to_dict(self):
        """Convert explanation to dictionary"""
        return {
            'id': self.id,
            'decision_id': self.decision_id,
            'explanation_method': self.explanation_method,
            'feature_importance': self.get_feature_importance(),
            'feature_values': self.get_feature_values(),
            'base_value': self.base_value,
            'explanation_text': self.explanation_text,
            'fairness_metrics': self.get_fairness_metrics(),
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

class Consent(db.Model):
    """Consent model for managing user data usage permissions"""
    __tablename__ = 'consents'
    
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id = db.Column(db.String(36), db.ForeignKey('users.id'), nullable=False)
    consent_type = db.Column(db.String(50), nullable=False)  # e.g., 'credit_scoring', 'fraud_detection', 'personalized_offers'
    is_granted = db.Column(db.Boolean, default=False)
    granted_at = db.Column(db.DateTime)
    revoked_at = db.Column(db.DateTime)
    purpose_description = db.Column(db.Text)
    data_retention_days = db.Column(db.Integer, default=365)
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), nullable=False)
    updated_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    
    def grant(self):
        """Grant consent"""
        self.is_granted = True
        self.granted_at = datetime.now(timezone.utc)
        self.revoked_at = None
    
    def revoke(self):
        """Revoke consent"""
        self.is_granted = False
        self.revoked_at = datetime.now(timezone.utc)
    
    def to_dict(self):
        """Convert consent to dictionary"""
        return {
            'id': self.id,
            'user_id': self.user_id,
            'consent_type': self.consent_type,
            'is_granted': self.is_granted,
            'granted_at': self.granted_at.isoformat() if self.granted_at else None,
            'revoked_at': self.revoked_at.isoformat() if self.revoked_at else None,
            'purpose_description': self.purpose_description,
            'data_retention_days': self.data_retention_days,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

class AuditLog(db.Model):
    """Audit Log model for tracking all system activities"""
    __tablename__ = 'audit_logs'
    
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id = db.Column(db.String(36), db.ForeignKey('users.id'), nullable=True)  # Can be null for system actions
    action_type = db.Column(db.String(50), nullable=False)  # e.g., 'login', 'ai_decision', 'consent_update', 'model_override'
    resource_type = db.Column(db.String(50))  # e.g., 'user', 'decision', 'consent', 'model'
    resource_id = db.Column(db.String(36))
    action_details = db.Column(db.Text)  # JSON string of action details
    ip_address = db.Column(db.String(45))  # IPv6 compatible
    user_agent = db.Column(db.String(500))
    status = db.Column(db.Enum('success', 'failure', 'warning', 'info', name='log_status'), default='success')
    risk_level = db.Column(db.Enum('low', 'medium', 'high', 'critical', name='risk_level'), default='low')
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), nullable=False, index=True)
    
    def set_action_details(self, details):
        """Set action details as JSON string"""
        self.action_details = json.dumps(details) if details else None
    
    def get_action_details(self):
        """Get action details as dictionary"""
        return json.loads(self.action_details) if self.action_details else {}
    
    def to_dict(self):
        """Convert audit log to dictionary"""
        return {
            'id': self.id,
            'user_id': self.user_id,
            'action_type': self.action_type,
            'resource_type': self.resource_type,
            'resource_id': self.resource_id,
            'action_details': self.get_action_details(),
            'ip_address': self.ip_address,
            'user_agent': self.user_agent,
            'status': self.status,
            'risk_level': self.risk_level,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'user': self.user.get_full_name() if self.user else 'System'
        }

class BiasAlert(db.Model):
    """Bias Alert model for tracking potential bias issues"""
    __tablename__ = 'bias_alerts'
    
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    model_name = db.Column(db.String(100), nullable=False)
    model_version = db.Column(db.String(20), nullable=False)
    alert_type = db.Column(db.String(50), nullable=False)  # e.g., 'demographic_parity', 'equal_opportunity', 'predictive_parity'
    metric_name = db.Column(db.String(50), nullable=False)
    threshold_value = db.Column(db.Float, nullable=False)
    actual_value = db.Column(db.Float, nullable=False)
    severity = db.Column(db.Enum('low', 'medium', 'high', 'critical', name='alert_severity'), default='medium')
    description = db.Column(db.Text)
    affected_groups = db.Column(db.Text)  # JSON string of affected demographic groups
    investigation_status = db.Column(db.Enum('open', 'investigating', 'resolved', 'false_positive', name='investigation_status'), default='open')
    resolution_notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), nullable=False)
    resolved_at = db.Column(db.DateTime)
    
    def set_affected_groups(self, groups):
        """Set affected groups as JSON string"""
        self.affected_groups = json.dumps(groups) if groups else None
    
    def get_affected_groups(self):
        """Get affected groups as list"""
        return json.loads(self.affected_groups) if self.affected_groups else []
    
    def resolve(self, notes=None):
        """Mark alert as resolved"""
        self.investigation_status = 'resolved'
        self.resolved_at = datetime.now(timezone.utc)
        if notes:
            self.resolution_notes = notes
    
    def to_dict(self):
        """Convert bias alert to dictionary"""
        return {
            'id': self.id,
            'model_name': self.model_name,
            'model_version': self.model_version,
            'alert_type': self.alert_type,
            'metric_name': self.metric_name,
            'threshold_value': self.threshold_value,
            'actual_value': self.actual_value,
            'severity': self.severity,
            'description': self.description,
            'affected_groups': self.get_affected_groups(),
            'investigation_status': self.investigation_status,
            'resolution_notes': self.resolution_notes,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'resolved_at': self.resolved_at.isoformat() if self.resolved_at else None
        }

class ModelPerformance(db.Model):
    """Model Performance tracking for AI models"""
    __tablename__ = 'model_performance'
    
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    model_name = db.Column(db.String(100), nullable=False)
    model_version = db.Column(db.String(20), nullable=False)
    accuracy = db.Column(db.Float)
    precision = db.Column(db.Float)
    recall = db.Column(db.Float)
    f1_score = db.Column(db.Float)
    auc_score = db.Column(db.Float)
    fairness_score = db.Column(db.Float)
    calibration_score = db.Column(db.Float)
    total_predictions = db.Column(db.Integer, default=0)
    evaluation_date = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), nullable=False)
    performance_metrics = db.Column(db.Text)  # JSON string for additional metrics
    
    def set_performance_metrics(self, metrics):
        """Set performance metrics as JSON string"""
        self.performance_metrics = json.dumps(metrics) if metrics else None
    
    def get_performance_metrics(self):
        """Get performance metrics as dictionary"""
        return json.loads(self.performance_metrics) if self.performance_metrics else {}
    
    def to_dict(self):
        """Convert model performance to dictionary"""
        return {
            'id': self.id,
            'model_name': self.model_name,
            'model_version': self.model_version,
            'accuracy': self.accuracy,
            'precision': self.precision,
            'recall': self.recall,
            'f1_score': self.f1_score,
            'auc_score': self.auc_score,
            'fairness_score': self.fairness_score,
            'calibration_score': self.calibration_score,
            'total_predictions': self.total_predictions,
            'evaluation_date': self.evaluation_date.isoformat() if self.evaluation_date else None,
            'performance_metrics': self.get_performance_metrics()
        }

class NotificationPreference(db.Model):
    """User notification preference settings"""
    __tablename__ = 'notification_preferences'

    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id = db.Column(db.String(36), db.ForeignKey('users.id'), nullable=False, unique=True)
    email_enabled = db.Column(db.Boolean, default=True)
    sms_enabled = db.Column(db.Boolean, default=False)
    push_enabled = db.Column(db.Boolean, default=False)
    weekly_summary_enabled = db.Column(db.Boolean, default=True)
    critical_alerts_only = db.Column(db.Boolean, default=False)
    quiet_hours_start = db.Column(db.String(5), default='22:00')
    quiet_hours_end = db.Column(db.String(5), default='07:00')
    preferred_channels = db.Column(db.Text)  # JSON string of per-topic channel prefs
    updated_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))

    def set_preferred_channels(self, channels):
        """Persist per-topic channel preferences"""
        self.preferred_channels = json.dumps(channels) if channels else None

    def get_preferred_channels(self):
        """Return stored per-topic channel preferences"""
        return json.loads(self.preferred_channels) if self.preferred_channels else {}

    def to_dict(self):
        """Serialize notification preferences"""
        return {
            'id': self.id,
            'user_id': self.user_id,
            'email_enabled': self.email_enabled,
            'sms_enabled': self.sms_enabled,
            'push_enabled': self.push_enabled,
            'weekly_summary_enabled': self.weekly_summary_enabled,
            'critical_alerts_only': self.critical_alerts_only,
            'quiet_hours': {
                'start': self.quiet_hours_start,
                'end': self.quiet_hours_end
            },
            'preferred_channels': self.get_preferred_channels(),
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

class DecisionOverride(db.Model):
    """Manual override events for AI decisions"""
    __tablename__ = 'decision_overrides'

    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    decision_id = db.Column(db.String(36), db.ForeignKey('ai_decisions.id'), nullable=False)
    requested_by = db.Column(db.String(36), db.ForeignKey('users.id'), nullable=False)
    approved_by = db.Column(db.String(36), db.ForeignKey('users.id'))
    target_user_id = db.Column(db.String(36), db.ForeignKey('users.id'), nullable=False)
    old_outcome = db.Column(db.String(50), nullable=False)
    new_outcome = db.Column(db.String(50), nullable=False)
    reason = db.Column(db.Text, nullable=False)
    reviewer_notes = db.Column(db.Text)
    status = db.Column(db.String(20), default='applied')  # applied, pending, rejected
    risk_level = db.Column(db.String(20), default='medium')
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), nullable=False)
    resolved_at = db.Column(db.DateTime)

    def finalize(self, status='applied', reviewer=None, notes=None):
        """Finalize override lifecycle"""
        self.status = status
        self.resolved_at = datetime.now(timezone.utc)
        if reviewer:
            self.approved_by = reviewer
        if notes:
            self.reviewer_notes = notes

    def to_dict(self):
        """Serialize override record"""
        return {
            'id': self.id,
            'decision_id': self.decision_id,
            'requested_by': self.requested_by,
            'approved_by': self.approved_by,
            'target_user_id': self.target_user_id,
            'old_outcome': self.old_outcome,
            'new_outcome': self.new_outcome,
            'reason': self.reason,
            'reviewer_notes': self.reviewer_notes,
            'status': self.status,
            'risk_level': self.risk_level,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'resolved_at': self.resolved_at.isoformat() if self.resolved_at else None
        }

# Seed data function for development
def create_sample_data():
    """Create sample data for development and testing"""
    from datetime import datetime, timezone, timedelta
    
    # Create sample users
    admin_user = User(
        email='admin@trustai.com',
        first_name='Admin',
        last_name='User',
        role='admin',
        department='IT'
    )
    admin_user.set_password('admin123')
    
    customer_user = User(
        email='customer@trustai.com',
        first_name='John',
        last_name='Doe',
        role='customer',
        department='Banking'
    )
    customer_user.set_password('customer123')
    
    compliance_user = User(
        email='compliance@trustai.com',
        first_name='Jane',
        last_name='Smith',
        role='compliance_officer',
        department='Risk Management'
    )
    compliance_user.set_password('compliance123')
    
    db.session.add_all([admin_user, customer_user, compliance_user])
    db.session.commit()
    
    # Create sample consents for customer
    consents = [
        Consent(
            user_id=customer_user.id,
            consent_type='credit_scoring',
            is_granted=True,
            purpose_description='AI-based credit assessment and loan approval decisions',
            data_retention_days=365
        ),
        Consent(
            user_id=customer_user.id,
            consent_type='fraud_detection',
            is_granted=True,
            purpose_description='Pattern recognition for fraudulent activity detection',
            data_retention_days=730
        ),
        Consent(
            user_id=customer_user.id,
            consent_type='personalized_offers',
            is_granted=False,
            purpose_description='Personalized product recommendations based on banking behavior',
            data_retention_days=180
        ),
        Consent(
            user_id=customer_user.id,
            consent_type='risk_profiling',
            is_granted=True,
            purpose_description='Behavioral analysis for risk assessment',
            data_retention_days=365
        )
    ]
    
    for consent in consents:
        consent.grant()
    
    db.session.add_all(consents)
    db.session.commit()

    # Create default notification preferences
    notification_prefs = [
        NotificationPreference(
            user_id=admin_user.id,
            email_enabled=True,
            sms_enabled=True,
            push_enabled=True,
            critical_alerts_only=False
        ),
        NotificationPreference(
            user_id=customer_user.id,
            email_enabled=True,
            sms_enabled=False,
            push_enabled=True,
            weekly_summary_enabled=True,
            critical_alerts_only=True
        ),
        NotificationPreference(
            user_id=compliance_user.id,
            email_enabled=True,
            sms_enabled=True,
            push_enabled=False
        )
    ]

    db.session.add_all(notification_prefs)
    db.session.commit()
    
    # Create sample AI decisions
    decisions = [
        AIDecision(
            user_id=customer_user.id,
            decision_type='loan_approval',
            model_name='credit_scoring_v2',
            model_version='2.3.1',
            outcome='approved',
            confidence_score=0.87,
            processing_time_ms=125
        ),
        AIDecision(
            user_id=customer_user.id,
            decision_type='credit_limit',
            model_name='credit_limit_optimizer',
            model_version='1.8.2',
            outcome='modified',
            confidence_score=0.92,
            processing_time_ms=98
        ),
        AIDecision(
            user_id=customer_user.id,
            decision_type='risk_assessment',
            model_name='risk_profiler',
            model_version='3.1.0',
            outcome='low_risk',
            confidence_score=0.95,
            processing_time_ms=156
        )
    ]
    
    for decision in decisions:
        # Set sample input data
        decision.set_input_data({
            'credit_score': 750,
            'income': 85000,
            'debt_to_income': 0.25,
            'employment_length': 5,
            'age': 35
        })
        decision.set_metadata({
            'region': 'northeast',
            'branch_id': 'BR001',
            'transaction_volume': 'high'
        })
    
    db.session.add_all(decisions)
    db.session.commit()
    
    # Create sample explanations
    explanations = [
        Explanation(
            decision_id=decisions[0].id,
            explanation_method='shap',
            base_value=0.5,
            explanation_text='The loan was approved primarily due to excellent credit history and stable income. All factors align with our fairness guidelines.'
        ),
        Explanation(
            decision_id=decisions[1].id,
            explanation_method='lime',
            base_value=0.45,
            explanation_text='Credit limit increased based on improved payment history and reduced debt-to-income ratio.'
        ),
        Explanation(
            decision_id=decisions[2].id,
            explanation_method='shap',
            base_value=0.3,
            explanation_text='Low risk assessment supported by consistent payment patterns and low credit utilization.'
        )
    ]
    
    for i, explanation in enumerate(explanations):
        # Set sample feature importance
        explanation.set_feature_importance({
            'credit_score': 0.35,
            'income': 0.25,
            'debt_to_income': 0.20,
            'employment_length': 0.15,
            'age': 0.05
        })
        explanation.set_fairness_metrics({
            'demographic_parity': 0.92,
            'equal_opportunity': 0.88,
            'predictive_parity': 0.94,
            'overall_accuracy': 0.96
        })
    
    db.session.add_all(explanations)
    db.session.commit()

    # Create sample override
    decision_override = DecisionOverride(
        decision_id=decisions[1].id,
        requested_by=admin_user.id,
        approved_by=admin_user.id,
        target_user_id=customer_user.id,
        old_outcome='modified',
        new_outcome='approved',
        reason='Manual review by admin for VIP customer',
        status='applied',
        risk_level='medium'
    )

    db.session.add(decision_override)
    db.session.commit()
    
    # Create sample bias alerts
    bias_alerts = [
        BiasAlert(
            model_name='credit_scoring_v2',
            model_version='2.3.1',
            alert_type='demographic_parity',
            metric_name='demographic_parity_score',
            threshold_value=0.90,
            actual_value=0.85,
            severity='high',
            description='Credit scoring model showing 5% variance across demographic groups',
            investigation_status='open'
        ),
        BiasAlert(
            model_name='risk_profiler',
            model_version='3.1.0',
            alert_type='regional_bias',
            metric_name='regional_approval_rate',
            threshold_value=0.80,
            actual_value=0.75,
            severity='medium',
            description='Loan approval rate for specific region below threshold',
            investigation_status='investigating'
        )
    ]
    
    for alert in bias_alerts:
        alert.set_affected_groups(['age_group_25_34', 'region_southwest'])
    
    db.session.add_all(bias_alerts)
    db.session.commit()
    
    # Create sample audit logs
    audit_logs = [
        AuditLog(
            user_id=customer_user.id,
            action_type='ai_decision',
            resource_type='decision',
            resource_id=decisions[0].id,
            status='success',
            risk_level='low',
            ip_address='192.168.1.100'
        ),
        AuditLog(
            user_id=customer_user.id,
            action_type='consent_update',
            resource_type='consent',
            resource_id=consents[0].id,
            status='success',
            risk_level='low',
            ip_address='192.168.1.100'
        ),
        AuditLog(
            user_id=admin_user.id,
            action_type='model_override',
            resource_type='decision',
            resource_id=decisions[1].id,
            status='success',
            risk_level='medium',
            ip_address='192.168.1.200'
        )
    ]
    
    for log in audit_logs:
        log.set_action_details({
            'browser': 'Chrome/120.0.0.0',
            'platform': 'Windows',
            'session_id': str(uuid.uuid4())
        })
    
    db.session.add_all(audit_logs)
    db.session.commit()
    
    print("Sample data created successfully!")

if __name__ == '__main__':
    print("TrustAI Database Models - Use with Flask application")
