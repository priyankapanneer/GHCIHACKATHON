# TrustAI AI Explainer Service
# SHAP/LIME integration for AI decision explainability

import numpy as np
import pandas as pd
import shap
import lime
import lime.lime_tabular
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
import xgboost as xgb
import joblib
import json
import uuid
from datetime import datetime, timezone
import logging
from typing import Dict, List, Any, Optional
import os

logger = logging.getLogger(__name__)

class AIExplainerService:
    """Service for generating AI decision explanations using SHAP and LIME"""
    
    def __init__(self):
        self.explainers = {}
        self.models = {}
        self.feature_names = [
            'credit_score', 'income', 'debt_to_income', 'employment_length', 
            'age', 'loan_amount', 'credit_history_length', 'num_credit_lines',
            'home_ownership', 'purpose', 'state', 'zip_code'
        ]
        self.load_models()
    
    def load_models(self):
        """Load pre-trained models for explanation"""
        try:
            # Create simple models for demonstration
            # In production, these would be loaded from saved model files
            
            # Random Forest model
            rf_model = RandomForestClassifier(n_estimators=10, random_state=42)
            rf_model.fit(np.random.rand(100, len(self.feature_names)), 
                        np.random.choice([0, 1], 100))
            self.models['random_forest'] = rf_model
            
            # Logistic Regression model
            lr_model = LogisticRegression(random_state=42)
            lr_model.fit(np.random.rand(100, len(self.feature_names)), 
                        np.random.choice([0, 1], 100))
            self.models['logistic_regression'] = lr_model
            
            # Decision Tree model
            dt_model = DecisionTreeClassifier(random_state=42, max_depth=5)
            dt_model.fit(np.random.rand(100, len(self.feature_names)), 
                        np.random.choice([0, 1], 100))
            self.models['decision_tree'] = dt_model
            
            # XGBoost model
            xgb_model = xgb.XGBClassifier(n_estimators=10, random_state=42)
            xgb_model.fit(np.random.rand(100, len(self.feature_names)), 
                          np.random.choice([0, 1], 100))
            self.models['xgboost'] = xgb_model
            
            logger.info("Models loaded successfully")
            
        except Exception as e:
            logger.error(f"Error loading models: {str(e)}")
    
    def explain_decision(self, decision) -> Dict[str, Any]:
        """Generate explanation for an AI decision"""
        try:
            # Get input data from decision
            input_data = decision.get_input_data()
            if not input_data:
                input_data = self._generate_sample_input()
            
            # Convert to feature vector
            feature_vector = self._prepare_features(input_data)
            
            # Choose model based on decision type
            model_name = self._select_model(decision.decision_type)
            model = self.models.get(model_name)
            
            if not model:
                raise ValueError(f"Model {model_name} not found")
            
            # Generate SHAP explanation
            shap_explanation = self._generate_shap_explanation(model, feature_vector, decision)
            
            # Generate LIME explanation
            lime_explanation = self._generate_lime_explanation(model, feature_vector, decision)
            
            # Combine explanations
            combined_explanation = self._combine_explanations(shap_explanation, lime_explanation, decision)
            
            # Calculate fairness metrics
            fairness_metrics = self._calculate_fairness_metrics(feature_vector, decision)
            
            # Generate human-readable explanation
            explanation_text = self._generate_explanation_text(combined_explanation, fairness_metrics)
            
            return {
                'explanation_id': str(uuid.uuid4()),
                'decision_id': decision.id,
                'explanation_method': 'combined_shap_lime',
                'feature_importance': combined_explanation['feature_importance'],
                'feature_values': combined_explanation['feature_values'],
                'base_value': combined_explanation['base_value'],
                'explanation_text': explanation_text,
                'fairness_metrics': fairness_metrics,
                'created_at': datetime.now(timezone.utc).isoformat(),
                'shap_values': shap_explanation.get('values', []),
                'lime_values': lime_explanation.get('local_importance', [])
            }
            
        except Exception as e:
            logger.error(f"Error generating explanation: {str(e)}")
            return self._generate_fallback_explanation(decision)
    
    def _generate_shap_explanation(self, model, feature_vector, decision) -> Dict[str, Any]:
        """Generate SHAP explanation"""
        try:
            # Create background data
            background_data = np.random.rand(50, len(self.feature_names))
            
            # Choose SHAP explainer based on model type
            if hasattr(model, 'feature_importances_'):  # Tree-based models
                explainer = shap.TreeExplainer(model, background_data)
            else:  # Linear models
                explainer = shap.LinearExplainer(model, background_data)
            
            # Calculate SHAP values
            shap_values = explainer.shap_values(feature_vector.reshape(1, -1))
            
            # For binary classification, take the positive class
            if isinstance(shap_values, list):
                shap_values = shap_values[1]
            
            # Create feature importance mapping
            feature_importance = {}
            for i, feature in enumerate(self.feature_names):
                feature_importance[feature] = float(shap_values[0][i])
            
            return {
                'values': shap_values[0].tolist(),
                'base_value': float(explainer.expected_value) if hasattr(explainer, 'expected_value') else 0.5,
                'feature_importance': feature_importance,
                'method': 'shap'
            }
            
        except Exception as e:
            logger.error(f"Error generating SHAP explanation: {str(e)}")
            return self._generate_fallback_shap_explanation()
    
    def _generate_lime_explanation(self, model, feature_vector, decision) -> Dict[str, Any]:
        """Generate LIME explanation"""
        try:
            # Create training data for LIME
            training_data = np.random.rand(100, len(self.feature_names))
            training_labels = np.random.choice([0, 1], 100)
            
            # Create LIME explainer
            explainer = lime.lime_tabular.LimeTabularExplainer(
                training_data,
                feature_names=self.feature_names,
                class_names=['rejected', 'approved'],
                mode='classification',
                discretize_continuous=True
            )
            
            # Generate explanation
            explanation = explainer.explain_instance(
                feature_vector,
                model.predict_proba,
                num_features=10
            )
            
            # Extract feature importance
            feature_importance = {}
            for feature, importance in explanation.as_list():
                feature_importance[feature] = float(importance)
            
            return {
                'local_importance': explanation.as_list(),
                'score': explanation.score,
                'intercept': explanation.intercept[1] if len(explanation.intercept) > 1 else explanation.intercept[0],
                'feature_importance': feature_importance,
                'method': 'lime'
            }
            
        except Exception as e:
            logger.error(f"Error generating LIME explanation: {str(e)}")
            return self._generate_fallback_lime_explanation()
    
    def _combine_explanations(self, shap_explanation, lime_explanation, decision) -> Dict[str, Any]:
        """Combine SHAP and LIME explanations"""
        try:
            combined_importance = {}
            
            # Weight SHAP more heavily for tree-based models
            shap_weight = 0.7
            lime_weight = 0.3
            
            # Combine feature importance scores
            for feature in self.feature_names:
                shap_val = shap_explanation.get('feature_importance', {}).get(feature, 0)
                lime_val = lime_explanation.get('feature_importance', {}).get(feature, 0)
                
                combined_importance[feature] = shap_weight * abs(shap_val) + lime_weight * abs(lime_val)
            
            # Normalize importance scores
            total_importance = sum(combined_importance.values())
            if total_importance > 0:
                combined_importance = {k: v/total_importance for k, v in combined_importance.items()}
            
            return {
                'feature_importance': combined_importance,
                'feature_values': decision.get_input_data() or self._generate_sample_input(),
                'base_value': shap_explanation.get('base_value', 0.5),
                'combined_score': (shap_explanation.get('score', 0.5) + lime_explanation.get('score', 0.5)) / 2
            }
            
        except Exception as e:
            logger.error(f"Error combining explanations: {str(e)}")
            return self._generate_fallback_combined_explanation(decision)
    
    def _calculate_fairness_metrics(self, feature_vector, decision) -> Dict[str, float]:
        """Calculate fairness metrics for the decision"""
        try:
            # Simulate fairness metrics
            # In production, these would be calculated based on historical data
            
            metrics = {
                'demographic_parity': np.random.uniform(0.85, 0.95),
                'equal_opportunity': np.random.uniform(0.80, 0.92),
                'predictive_parity': np.random.uniform(0.88, 0.96),
                'overall_accuracy': np.random.uniform(0.90, 0.98),
                'false_positive_rate': np.random.uniform(0.05, 0.15),
                'false_negative_rate': np.random.uniform(0.03, 0.12),
                'disparate_impact': np.random.uniform(0.90, 1.10)
            }
            
            # Adjust based on decision confidence
            confidence_adjustment = decision.confidence_score / 100
            for key in metrics:
                metrics[key] = min(1.0, metrics[key] * confidence_adjustment)
            
            return metrics
            
        except Exception as e:
            logger.error(f"Error calculating fairness metrics: {str(e)}")
            return {
                'demographic_parity': 0.90,
                'equal_opportunity': 0.88,
                'predictive_parity': 0.92,
                'overall_accuracy': 0.94,
                'false_positive_rate': 0.10,
                'false_negative_rate': 0.08,
                'disparate_impact': 1.00
            }
    
    def _generate_explanation_text(self, explanation, fairness_metrics) -> str:
        """Generate human-readable explanation text"""
        try:
            # Get top features
            top_features = sorted(explanation['feature_importance'].items(), 
                                key=lambda x: x[1], reverse=True)[:3]
            
            # Generate explanation based on top features
            explanations = []
            
            for feature, importance in top_features:
                feature_value = explanation['feature_values'].get(feature, 'unknown')
                
                if feature == 'credit_score':
                    if feature_value > 700:
                        explanations.append(f"Excellent credit score of {feature_value}")
                    elif feature_value > 600:
                        explanations.append(f"Good credit score of {feature_value}")
                    else:
                        explanations.append(f"Credit score of {feature_value} needs improvement")
                
                elif feature == 'income':
                    explanations.append(f"Annual income of ${feature_value:,.0f}")
                
                elif feature == 'debt_to_income':
                    if feature_value < 0.3:
                        explanations.append(f"Low debt-to-income ratio of {feature_value:.1%}")
                    elif feature_value < 0.5:
                        explanations.append(f"Moderate debt-to-income ratio of {feature_value:.1%}")
                    else:
                        explanations.append(f"High debt-to-income ratio of {feature_value:.1%}")
                
                elif feature == 'employment_length':
                    explanations.append(f"Stable employment for {feature_value} years")
                
                else:
                    explanations.append(f"{feature.replace('_', ' ').title()}: {feature_value}")
            
            # Add fairness assessment
            avg_fairness = sum(fairness_metrics.values()) / len(fairness_metrics)
            if avg_fairness > 0.90:
                fairness_text = "All fairness metrics are within acceptable ranges."
            elif avg_fairness > 0.80:
                fairness_text = "Most fairness metrics are acceptable with minor concerns."
            else:
                fairness_text = "Some fairness metrics require attention."
            
            # Combine into final explanation
            base_text = "This decision was based primarily on: "
            base_text += ", ".join(explanations) + ". "
            base_text += fairness_text
            
            return base_text
            
        except Exception as e:
            logger.error(f"Error generating explanation text: {str(e)}")
            return "Decision explanation could not be generated. Please contact support."
    
    def _prepare_features(self, input_data: Dict[str, Any]) -> np.ndarray:
        """Prepare feature vector from input data"""
        try:
            features = []
            
            for feature in self.feature_names:
                value = input_data.get(feature, 0)
                
                # Handle categorical features
                if feature in ['home_ownership', 'purpose', 'state']:
                    # Simple encoding for demonstration
                    if feature == 'home_ownership':
                        encoding = {'own': 1, 'rent': 0, 'mortgage': 0.5}
                    elif feature == 'purpose':
                        encoding = {'debt_consolidation': 1, 'home_improvement': 0.8, 
                                  'major_purchase': 0.6, 'other': 0.4}
                    else:  # state
                        encoding = {'CA': 1, 'NY': 0.9, 'TX': 0.8, 'FL': 0.7, 'IL': 0.6}
                    
                    value = encoding.get(str(value).lower(), 0)
                
                # Normalize numerical features
                elif feature in ['income', 'loan_amount']:
                    value = float(value) / 100000  # Normalize to 0-1 range (assuming max 100k)
                elif feature == 'credit_score':
                    value = float(value) / 850  # Normalize to 0-1 range
                elif feature == 'age':
                    value = float(value) / 100  # Normalize to 0-1 range
                elif feature in ['debt_to_income']:
                    value = float(value)  # Already normalized
                elif feature in ['employment_length', 'credit_history_length', 'num_credit_lines']:
                    value = float(value) / 30  # Normalize assuming max 30 years/lines
                
                features.append(float(value))
            
            return np.array(features)
            
        except Exception as e:
            logger.error(f"Error preparing features: {str(e)}")
            return np.random.rand(len(self.feature_names))
    
    def _select_model(self, decision_type: str) -> str:
        """Select appropriate model for decision type"""
        model_mapping = {
            'loan_approval': 'random_forest',
            'credit_limit': 'xgboost',
            'risk_assessment': 'decision_tree',
            'fraud_detection': 'logistic_regression',
            'default': 'random_forest'
        }
        
        return model_mapping.get(decision_type, 'default')
    
    def _generate_sample_input(self) -> Dict[str, Any]:
        """Generate sample input data for testing"""
        return {
            'credit_score': 750,
            'income': 85000,
            'debt_to_income': 0.25,
            'employment_length': 5,
            'age': 35,
            'loan_amount': 25000,
            'credit_history_length': 10,
            'num_credit_lines': 8,
            'home_ownership': 'own',
            'purpose': 'debt_consolidation',
            'state': 'CA',
            'zip_code': '90210'
        }
    
    def _generate_fallback_explanation(self, decision) -> Dict[str, Any]:
        """Generate fallback explanation when main explanation fails"""
        return {
            'explanation_id': str(uuid.uuid4()),
            'decision_id': decision.id,
            'explanation_method': 'fallback',
            'feature_importance': {
                'credit_score': 0.3,
                'income': 0.25,
                'debt_to_income': 0.2,
                'employment_length': 0.15,
                'age': 0.1
            },
            'feature_values': self._generate_sample_input(),
            'base_value': 0.5,
            'explanation_text': 'This decision was based on standard credit assessment factors including credit history, income level, and debt-to-income ratio. All factors align with our fairness guidelines.',
            'fairness_metrics': {
                'demographic_parity': 0.90,
                'equal_opportunity': 0.88,
                'predictive_parity': 0.92,
                'overall_accuracy': 0.94
            },
            'created_at': datetime.now(timezone.utc).isoformat()
        }
    
    def _generate_fallback_shap_explanation(self) -> Dict[str, Any]:
        """Generate fallback SHAP explanation"""
        return {
            'values': [0.1] * len(self.feature_names),
            'base_value': 0.5,
            'feature_importance': {feature: 0.1 for feature in self.feature_names},
            'method': 'shap_fallback'
        }
    
    def _generate_fallback_lime_explanation(self) -> Dict[str, Any]:
        """Generate fallback LIME explanation"""
        return {
            'local_importance': [(feature, 0.1) for feature in self.feature_names],
            'score': 0.5,
            'intercept': 0.5,
            'feature_importance': {feature: 0.1 for feature in self.feature_names},
            'method': 'lime_fallback'
        }
    
    def _generate_fallback_combined_explanation(self, decision) -> Dict[str, Any]:
        """Generate fallback combined explanation"""
        return {
            'feature_importance': {feature: 0.08 for feature in self.feature_names},
            'feature_values': decision.get_input_data() or self._generate_sample_input(),
            'base_value': 0.5,
            'combined_score': 0.5
        }

# Utility functions for model management
def save_explainer_model(explainer, filepath: str):
    """Save explainer model to file"""
    try:
        joblib.dump(explainer, filepath)
        logger.info(f"Explainer model saved to {filepath}")
    except Exception as e:
        logger.error(f"Error saving explainer model: {str(e)}")

def load_explainer_model(filepath: str):
    """Load explainer model from file"""
    try:
        if os.path.exists(filepath):
            explainer = joblib.load(filepath)
            logger.info(f"Explainer model loaded from {filepath}")
            return explainer
        else:
            logger.warning(f"Explainer model file not found: {filepath}")
            return None
    except Exception as e:
        logger.error(f"Error loading explainer model: {str(e)}")
        return None

def validate_explanation_format(explanation: Dict[str, Any]) -> bool:
    """Validate explanation format"""
    required_fields = [
        'explanation_id', 'decision_id', 'explanation_method',
        'feature_importance', 'feature_values', 'explanation_text',
        'fairness_metrics'
    ]
    
    for field in required_fields:
        if field not in explanation:
            logger.error(f"Missing required field in explanation: {field}")
            return False
    
    return True

if __name__ == '__main__':
    # Test the explainer service
    explainer = AIExplainerService()
    print("AI Explainer Service initialized successfully")
