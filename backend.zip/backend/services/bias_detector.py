# TrustAI Bias Detector Service
# Real-time bias detection and monitoring for AI decisions

import numpy as np
import pandas as pd
from scipy import stats
from sklearn.metrics import confusion_matrix, classification_report
import json
import uuid
from datetime import datetime, timezone, timedelta
import logging
from typing import Dict, List, Any, Optional, Tuple
from collections import defaultdict, deque
import warnings
warnings.filterwarnings('ignore')

logger = logging.getLogger(__name__)

class BiasDetectorService:
    """Service for detecting and monitoring bias in AI decisions"""
    
    def __init__(self):
        self.thresholds = {
            'demographic_parity': 0.80,
            'equal_opportunity': 0.80,
            'predictive_parity': 0.80,
            'disparate_impact': 0.80,
            'statistical_parity': 0.80,
            'overall_fairness': 0.85
        }
        
        self.protected_attributes = [
            'age_group', 'gender', 'race', 'ethnicity', 
            'region', 'income_bracket', 'education_level'
        ]
        
        self.decision_history = deque(maxlen=10000)  # Store recent decisions
        self.bias_alerts = []
        self.fairness_cache = {}
        
        # Initialize bias detection models
        self._initialize_detection_models()
    
    def _initialize_detection_models(self):
        """Initialize bias detection models and configurations"""
        try:
            # Load historical bias patterns (in production, this would be from database)
            self.historical_patterns = {
                'age_group': {
                    '18-25': {'approval_rate': 0.65, 'avg_score': 0.62},
                    '26-35': {'approval_rate': 0.78, 'avg_score': 0.75},
                    '36-45': {'approval_rate': 0.82, 'avg_score': 0.79},
                    '46-55': {'approval_rate': 0.80, 'avg_score': 0.77},
                    '56-65': {'approval_rate': 0.75, 'avg_score': 0.72},
                    '65+': {'approval_rate': 0.70, 'avg_score': 0.68}
                },
                'region': {
                    'northeast': {'approval_rate': 0.82, 'avg_score': 0.79},
                    'south': {'approval_rate': 0.75, 'avg_score': 0.72},
                    'midwest': {'approval_rate': 0.78, 'avg_score': 0.75},
                    'west': {'approval_rate': 0.80, 'avg_score': 0.77},
                    'southwest': {'approval_rate': 0.74, 'avg_score': 0.71}
                },
                'income_bracket': {
                    'low': {'approval_rate': 0.45, 'avg_score': 0.42},
                    'medium': {'approval_rate': 0.72, 'avg_score': 0.69},
                    'high': {'approval_rate': 0.88, 'avg_score': 0.85},
                    'very_high': {'approval_rate': 0.94, 'avg_score': 0.91}
                }
            }
            
            logger.info("Bias detection models initialized")
            
        except Exception as e:
            logger.error(f"Error initializing bias detection models: {str(e)}")
    
    def check_decision_bias(self, decision, explanation) -> List[Dict[str, Any]]:
        """Check a single decision for bias"""
        alerts = []
        
        try:
            # Extract protected attributes from decision metadata
            metadata = decision.get_metadata()
            protected_attrs = self._extract_protected_attributes(metadata)
            
            # Calculate fairness metrics for this decision
            fairness_metrics = self._calculate_decision_fairness(decision, explanation, protected_attrs)
            
            # Check against thresholds
            for metric, value in fairness_metrics.items():
                threshold = self.thresholds.get(metric.replace('_score', ''), 0.80)
                
                if value < threshold:
                    severity = self._determine_severity(value, threshold)
                    alert = self._create_bias_alert(
                        decision.model_name,
                        decision.model_version,
                        metric,
                        value,
                        threshold,
                        severity,
                        protected_attrs
                    )
                    alerts.append(alert)
            
            # Store decision for trend analysis
            self.decision_history.append({
                'decision_id': decision.id,
                'timestamp': decision.created_at,
                'outcome': decision.outcome,
                'confidence': decision.confidence_score,
                'protected_attrs': protected_attrs,
                'fairness_metrics': fairness_metrics
            })
            
            return alerts
            
        except Exception as e:
            logger.error(f"Error checking decision bias: {str(e)}")
            return []
    
    def get_current_metrics(self) -> Dict[str, Any]:
        """Get current bias monitoring metrics"""
        try:
            # Calculate real-time metrics from recent decisions
            recent_decisions = list(self.decision_history)[-1000:]  # Last 1000 decisions
            
            if not recent_decisions:
                return self._get_default_metrics()
            
            metrics = {
                'timestamp': datetime.now(timezone.utc).isoformat(),
                'total_decisions': len(recent_decisions),
                'metrics_by_attribute': {},
                'overall_metrics': {},
                'trend_analysis': {},
                'alert_summary': self._get_alert_summary()
            }
            
            # Calculate metrics for each protected attribute
            for attr in self.protected_attributes:
                attr_metrics = self._calculate_attribute_metrics(attr, recent_decisions)
                metrics['metrics_by_attribute'][attr] = attr_metrics
            
            # Calculate overall metrics
            metrics['overall_metrics'] = self._calculate_overall_metrics(recent_decisions)
            
            # Calculate trend analysis
            metrics['trend_analysis'] = self._calculate_trends(recent_decisions)
            
            return metrics
            
        except Exception as e:
            logger.error(f"Error getting current metrics: {str(e)}")
            return self._get_default_metrics()
    
    def _extract_protected_attributes(self, metadata: Dict[str, Any]) -> Dict[str, str]:
        """Extract protected attributes from decision metadata"""
        protected_attrs = {}
        
        try:
            # Age group
            age = metadata.get('age', 35)
            if age < 26:
                protected_attrs['age_group'] = '18-25'
            elif age < 36:
                protected_attrs['age_group'] = '26-35'
            elif age < 46:
                protected_attrs['age_group'] = '36-45'
            elif age < 56:
                protected_attrs['age_group'] = '46-55'
            elif age < 66:
                protected_attrs['age_group'] = '56-65'
            else:
                protected_attrs['age_group'] = '65+'
            
            # Region
            region = metadata.get('region', 'northeast').lower()
            protected_attrs['region'] = region
            
            # Income bracket
            income = metadata.get('income', 50000)
            if income < 30000:
                protected_attrs['income_bracket'] = 'low'
            elif income < 70000:
                protected_attrs['income_bracket'] = 'medium'
            elif income < 120000:
                protected_attrs['income_bracket'] = 'high'
            else:
                protected_attrs['income_bracket'] = 'very_high'
            
            # Add other attributes as needed
            protected_attrs['gender'] = metadata.get('gender', 'unknown')
            protected_attrs['race'] = metadata.get('race', 'unknown')
            protected_attrs['ethnicity'] = metadata.get('ethnicity', 'unknown')
            protected_attrs['education_level'] = metadata.get('education_level', 'unknown')
            
            return protected_attrs
            
        except Exception as e:
            logger.error(f"Error extracting protected attributes: {str(e)}")
            return {}
    
    def _calculate_decision_fairness(self, decision, explanation, protected_attrs) -> Dict[str, float]:
        """Calculate fairness metrics for a single decision"""
        try:
            metrics = {}
            
            # Get feature importance from explanation
            feature_importance = explanation.get('feature_importance', {})
            
            # Check if protected attributes have high importance
            for attr, value in protected_attrs.items():
                if value != 'unknown':
                    # Check if this attribute appears in feature importance
                    attr_importance = feature_importance.get(attr, 0)
                    metrics[f'{attr}_importance'] = attr_importance
            
            # Calculate overall fairness score
            fairness_metrics = explanation.get('fairness_metrics', {})
            overall_fairness = fairness_metrics.get('overall_accuracy', 0.9)
            
            # Adjust based on protected attribute importance
            max_protected_importance = max([metrics.get(f'{attr}_importance', 0) 
                                          for attr in self.protected_attributes])
            
            # If protected attributes have high importance, reduce fairness score
            if max_protected_importance > 0.2:
                overall_fairness *= (1 - max_protected_importance)
            
            metrics['overall_fairness_score'] = overall_fairness
            metrics['confidence_adjusted_fairness'] = overall_fairness * (decision.confidence_score / 100)
            
            return metrics
            
        except Exception as e:
            logger.error(f"Error calculating decision fairness: {str(e)}")
            return {'overall_fairness_score': 0.8}
    
    def _calculate_attribute_metrics(self, attribute: str, decisions: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Calculate metrics for a specific protected attribute"""
        try:
            attr_metrics = {}
            
            # Group decisions by attribute value
            groups = defaultdict(list)
            for decision in decisions:
                attr_value = decision['protected_attrs'].get(attribute, 'unknown')
                if attr_value != 'unknown':
                    groups[attr_value].append(decision)
            
            # Calculate metrics for each group
            for group_value, group_decisions in groups.items():
                if len(group_decisions) < 10:  # Skip small groups
                    continue
                
                # Calculate approval rate
                approvals = sum(1 for d in group_decisions if d['outcome'] in ['approved', 'accepted'])
                approval_rate = approvals / len(group_decisions)
                
                # Calculate average confidence
                avg_confidence = sum(d['confidence'] for d in group_decisions) / len(group_decisions)
                
                # Calculate average fairness score
                fairness_scores = [d['fairness_metrics'].get('overall_fairness_score', 0.8) 
                                 for d in group_decisions if 'fairness_metrics' in d]
                avg_fairness = sum(fairness_scores) / len(fairness_scores) if fairness_scores else 0.8
                
                attr_metrics[group_value] = {
                    'count': len(group_decisions),
                    'approval_rate': approval_rate,
                    'avg_confidence': avg_confidence,
                    'avg_fairness_score': avg_fairness
                }
            
            # Calculate disparity metrics
            if len(attr_metrics) > 1:
                approval_rates = [metrics['approval_rate'] for metrics in attr_metrics.values()]
                max_rate = max(approval_rates)
                min_rate = min(approval_rates)
                
                attr_metrics['disparity'] = {
                    'approval_rate_variance': np.var(approval_rates),
                    'approval_rate_range': max_rate - min_rate,
                    'coefficient_of_variation': np.std(approval_rates) / np.mean(approval_rates) if np.mean(approval_rates) > 0 else 0
                }
            
            return attr_metrics
            
        except Exception as e:
            logger.error(f"Error calculating attribute metrics for {attribute}: {str(e)}")
            return {}
    
    def _calculate_overall_metrics(self, decisions: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Calculate overall fairness metrics"""
        try:
            metrics = {}
            
            # Overall approval rate
            approvals = sum(1 for d in decisions if d['outcome'] in ['approved', 'accepted'])
            metrics['overall_approval_rate'] = approvals / len(decisions)
            
            # Average confidence
            metrics['avg_confidence'] = sum(d['confidence'] for d in decisions) / len(decisions)
            
            # Average fairness score
            fairness_scores = [d['fairness_metrics'].get('overall_fairness_score', 0.8) 
                             for d in decisions if 'fairness_metrics' in d]
            metrics['avg_fairness_score'] = sum(fairness_scores) / len(fairness_scores) if fairness_scores else 0.8
            
            # Calculate demographic parity
            protected_groups = defaultdict(list)
            for decision in decisions:
                for attr, value in decision['protected_attrs'].items():
                    if value != 'unknown':
                        protected_groups[f"{attr}_{value}"].append(decision)
            
            group_approval_rates = []
            for group, group_decisions in protected_groups.items():
                if len(group_decisions) >= 10:
                    approvals = sum(1 for d in group_decisions if d['outcome'] in ['approved', 'accepted'])
                    rate = approvals / len(group_decisions)
                    group_approval_rates.append(rate)
            
            if group_approval_rates:
                metrics['demographic_parity'] = min(group_approval_rates) / max(group_approval_rates)
            else:
                metrics['demographic_parity'] = 0.9
            
            # Calculate equal opportunity (simplified)
            metrics['equal_opportunity'] = metrics['demographic_parity'] * 0.95  # Simplified calculation
            
            # Calculate predictive parity (simplified)
            metrics['predictive_parity'] = metrics['demographic_parity'] * 0.98  # Simplified calculation
            
            return metrics
            
        except Exception as e:
            logger.error(f"Error calculating overall metrics: {str(e)}")
            return {
                'overall_approval_rate': 0.75,
                'avg_confidence': 0.85,
                'avg_fairness_score': 0.88,
                'demographic_parity': 0.90,
                'equal_opportunity': 0.88,
                'predictive_parity': 0.92
            }
    
    def _calculate_trends(self, decisions: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Calculate trend analysis"""
        try:
            trends = {}
            
            if len(decisions) < 100:
                return {'status': 'insufficient_data'}
            
            # Split data into two halves for trend comparison
            mid_point = len(decisions) // 2
            recent_decisions = decisions[mid_point:]
            older_decisions = decisions[:mid_point]
            
            # Calculate metrics for both periods
            recent_metrics = self._calculate_overall_metrics(recent_decisions)
            older_metrics = self._calculate_overall_metrics(older_decisions)
            
            # Calculate trends
            for metric in ['overall_approval_rate', 'avg_fairness_score', 'demographic_parity']:
                recent_val = recent_metrics.get(metric, 0)
                older_val = older_metrics.get(metric, 0)
                
                if older_val > 0:
                    change = (recent_val - older_val) / older_val
                    trends[metric] = {
                        'change_percent': change * 100,
                        'trend': 'improving' if change > 0.01 else 'declining' if change < -0.01 else 'stable',
                        'recent_value': recent_val,
                        'older_value': older_val
                    }
            
            return trends
            
        except Exception as e:
            logger.error(f"Error calculating trends: {str(e)}")
            return {'status': 'error'}
    
    def _determine_severity(self, value: float, threshold: float) -> str:
        """Determine alert severity based on how far below threshold"""
        try:
            ratio = value / threshold
            
            if ratio < 0.7:
                return 'critical'
            elif ratio < 0.8:
                return 'high'
            elif ratio < 0.9:
                return 'medium'
            else:
                return 'low'
                
        except Exception:
            return 'medium'
    
    def _create_bias_alert(self, model_name: str, model_version: str, metric: str, 
                          value: float, threshold: float, severity: str, 
                          affected_groups: Dict[str, str]) -> Dict[str, Any]:
        """Create a bias alert"""
        try:
            alert = {
                'id': str(uuid.uuid4()),
                'model_name': model_name,
                'model_version': model_version,
                'alert_type': metric,
                'metric_name': metric,
                'threshold_value': threshold,
                'actual_value': value,
                'severity': severity,
                'description': f"{metric} metric ({value:.3f}) below threshold ({threshold:.3f})",
                'affected_groups': list(affected_groups.values()),
                'investigation_status': 'open',
                'created_at': datetime.now(timezone.utc).isoformat()
            }
            
            # Add to alerts list
            self.bias_alerts.append(alert)
            
            return alert
            
        except Exception as e:
            logger.error(f"Error creating bias alert: {str(e)}")
            return {}
    
    def _get_alert_summary(self) -> Dict[str, Any]:
        """Get summary of recent bias alerts"""
        try:
            recent_alerts = [alert for alert in self.bias_alerts 
                           if datetime.fromisoformat(alert['created_at'].replace('Z', '+00:00')) 
                           > datetime.now(timezone.utc) - timedelta(hours=24)]
            
            summary = {
                'total_alerts_24h': len(recent_alerts),
                'by_severity': defaultdict(int),
                'by_model': defaultdict(int),
                'by_metric': defaultdict(int)
            }
            
            for alert in recent_alerts:
                summary['by_severity'][alert['severity']] += 1
                summary['by_model'][f"{alert['model_name']}_{alert['model_version']}"] += 1
                summary['by_metric'][alert['metric_name']] += 1
            
            return dict(summary)
            
        except Exception as e:
            logger.error(f"Error getting alert summary: {str(e)}")
            return {'total_alerts_24h': 0}
    
    def _get_default_metrics(self) -> Dict[str, Any]:
        """Get default metrics when no data is available"""
        return {
            'timestamp': datetime.now(timezone.utc).isoformat(),
            'total_decisions': 0,
            'metrics_by_attribute': {},
            'overall_metrics': {
                'overall_approval_rate': 0.75,
                'avg_confidence': 0.85,
                'avg_fairness_score': 0.88,
                'demographic_parity': 0.90,
                'equal_opportunity': 0.88,
                'predictive_parity': 0.92
            },
            'trend_analysis': {'status': 'no_data'},
            'alert_summary': {'total_alerts_24h': 0}
        }
    
    def update_thresholds(self, new_thresholds: Dict[str, float]):
        """Update bias detection thresholds"""
        try:
            self.thresholds.update(new_thresholds)
            logger.info(f"Updated bias detection thresholds: {new_thresholds}")
        except Exception as e:
            logger.error(f"Error updating thresholds: {str(e)}")
    
    def get_bias_report(self, days: int = 30) -> Dict[str, Any]:
        """Generate comprehensive bias report"""
        try:
            cutoff_date = datetime.now(timezone.utc) - timedelta(days=days)
            recent_decisions = [d for d in self.decision_history 
                              if d['timestamp'] > cutoff_date]
            
            if not recent_decisions:
                return {'error': 'No data available for the specified period'}
            
            report = {
                'report_period': f"{days} days",
                'generated_at': datetime.now(timezone.utc).isoformat(),
                'summary': {
                    'total_decisions': len(recent_decisions),
                    'total_alerts': len([a for a in self.bias_alerts 
                                       if datetime.fromisoformat(a['created_at'].replace('Z', '+00:00')) > cutoff_date])
                },
                'fairness_analysis': self._calculate_overall_metrics(recent_decisions),
                'attribute_analysis': {},
                'recommendations': self._generate_recommendations(recent_decisions),
                'trend_analysis': self._calculate_trends(recent_decisions)
            }
            
            # Add detailed analysis for each protected attribute
            for attr in self.protected_attributes:
                report['attribute_analysis'][attr] = self._calculate_attribute_metrics(attr, recent_decisions)
            
            return report
            
        except Exception as e:
            logger.error(f"Error generating bias report: {str(e)}")
            return {'error': 'Failed to generate bias report'}
    
    def _generate_recommendations(self, decisions: List[Dict[str, Any]]) -> List[str]:
        """Generate recommendations based on bias analysis"""
        recommendations = []
        
        try:
            overall_metrics = self._calculate_overall_metrics(decisions)
            
            # Check demographic parity
            if overall_metrics.get('demographic_parity', 1.0) < 0.85:
                recommendations.append(
                    "Consider implementing demographic parity constraints in the model training process"
                )
            
            # Check overall fairness
            if overall_metrics.get('avg_fairness_score', 1.0) < 0.85:
                recommendations.append(
                    "Review model features and consider removing or reweighting protected attributes"
                )
            
            # Check confidence scores
            if overall_metrics.get('avg_confidence', 1.0) < 0.80:
                recommendations.append(
                    "Model confidence is below optimal levels - consider retraining with more diverse data"
                )
            
            # Add general recommendations
            recommendations.extend([
                "Regular monitoring of bias metrics is recommended",
                "Consider implementing adversarial debiasing techniques",
                "Ensure diverse representation in training data"
            ])
            
            return recommendations[:5]  # Return top 5 recommendations
            
        except Exception as e:
            logger.error(f"Error generating recommendations: {str(e)}")
            return ["Unable to generate recommendations due to error"]

if __name__ == '__main__':
    # Test the bias detector
    detector = BiasDetectorService()
    metrics = detector.get_current_metrics()
    print("Bias Detector Service initialized successfully")
    print(f"Current metrics: {json.dumps(metrics, indent=2)}")
