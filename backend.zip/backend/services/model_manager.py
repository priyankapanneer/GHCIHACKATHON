# TrustAI Model Manager Service
# Lightweight ML models for banking decisions with explainability

import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
import xgboost as xgb
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score
import joblib
import json
import uuid
from datetime import datetime, timezone
import logging
from typing import Dict, List, Any, Optional, Tuple
import os
import warnings
warnings.filterwarnings('ignore')

logger = logging.getLogger(__name__)

class ModelManagerService:
    """Service for managing AI models and making predictions"""
    
    def __init__(self):
        self.models = {}
        self.scalers = {}
        self.encoders = {}
        self.model_metadata = {}
        
        # Initialize models
        self._initialize_models()
        self._load_pretrained_models()
    
    def _initialize_models(self):
        """Initialize lightweight models for banking decisions"""
        try:
            # Feature definitions for different decision types
            self.feature_definitions = {
                'loan_approval': {
                    'numerical': ['credit_score', 'income', 'debt_to_income', 'employment_length', 
                                 'age', 'loan_amount', 'credit_history_length', 'num_credit_lines'],
                    'categorical': ['home_ownership', 'purpose', 'state', 'zip_code'],
                    'target': 'approved'
                },
                'credit_limit': {
                    'numerical': ['credit_score', 'income', 'debt_to_income', 'employment_length',
                                 'age', 'current_limit', 'payment_history', 'account_age'],
                    'categorical': ['account_type', 'customer_segment', 'region'],
                    'target': 'limit_increase'
                },
                'risk_assessment': {
                    'numerical': ['credit_score', 'income', 'debt_to_income', 'employment_length',
                                 'age', 'payment_history', 'delinquencies', 'credit_utilization'],
                    'categorical': ['account_type', 'customer_segment', 'region'],
                    'target': 'risk_level'
                },
                'fraud_detection': {
                    'numerical': ['transaction_amount', 'transaction_frequency', 'account_age',
                                 'avg_transaction_amount', 'time_since_last_transaction'],
                    'categorical': ['transaction_type', 'merchant_category', 'device_type', 'location'],
                    'target': 'fraud'
                }
            }
            
            # Load model configurations from JSON file
            config_path = os.path.join(os.path.dirname(__file__), 'model_configs.json')
            with open(config_path, 'r') as f:
                self.model_configs = json.load(f)
            
            logger.info("Model configurations loaded from model_configs.json")
            
        except Exception as e:
            logger.error(f"Error initializing model configurations: {str(e)}")
    
    def _load_pretrained_models(self):
        """Load or create pretrained models"""
        try:
            for decision_type, config in self.model_configs.items():
                model = self._create_model(config)
                
                # Create synthetic training data for demonstration
                X_train, y_train, feature_names = self._generate_synthetic_data(decision_type)
                
                # Train model
                model.fit(X_train, y_train)
                
                # Create scaler for numerical features
                scaler = StandardScaler()
                numerical_features = self.feature_definitions[decision_type]['numerical']
                if len(numerical_features) > 0:
                    X_numerical = X_train[:, :len(numerical_features)]
                    scaler.fit(X_numerical)
                
                # Store model and preprocessing objects
                self.models[decision_type] = model
                self.scalers[decision_type] = scaler
                self.model_metadata[decision_type] = {
                    'feature_names': feature_names,
                    'numerical_features': numerical_features,
                    'categorical_features': self.feature_definitions[decision_type]['categorical'],
                    'model_type': config['model_type'],
                    'trained_at': datetime.now(timezone.utc).isoformat(),
                    'accuracy': accuracy_score(y_train, model.predict(X_train)),
                    'training_samples': len(X_train)
                }
                
                # Create label encoders for categorical features
                encoders = {}
                for i, cat_feature in enumerate(self.feature_definitions[decision_type]['categorical']):
                    encoder = LabelEncoder()
                    # Sample categories for encoding
                    categories = self._get_sample_categories(cat_feature)
                    encoder.fit(categories)
                    encoders[cat_feature] = encoder
                
                self.encoders[decision_type] = encoders
            
            logger.info("Models loaded and trained successfully")
            
        except Exception as e:
            logger.error(f"Error loading pretrained models: {str(e)}")
    
    def _create_model(self, config: Dict[str, Any]):
        """Create model based on configuration"""
        model_type = config['model_type']
        
        if model_type == 'random_forest':
            return RandomForestClassifier(
                n_estimators=config.get('n_estimators', 50),
                max_depth=config.get('max_depth', 8),
                random_state=config.get('random_state', 42)
            )
        elif model_type == 'xgboost':
            return xgb.XGBClassifier(
                n_estimators=config.get('n_estimators', 30),
                max_depth=config.get('max_depth', 6),
                learning_rate=config.get('learning_rate', 0.1),
                random_state=config.get('random_state', 42)
            )
        elif model_type == 'decision_tree':
            return DecisionTreeClassifier(
                max_depth=config.get('max_depth', 10),
                min_samples_split=config.get('min_samples_split', 20),
                random_state=config.get('random_state', 42)
            )
        elif model_type == 'logistic_regression':
            return LogisticRegression(
                random_state=config.get('random_state', 42),
                max_iter=config.get('max_iter', 1000)
            )
        else:
            raise ValueError(f"Unknown model type: {model_type}")
    
    def _generate_synthetic_data(self, decision_type: str) -> Tuple[np.ndarray, np.ndarray, List[str]]:
        """Generate synthetic training data for demonstration"""
        try:
            np.random.seed(42)
            n_samples = 1000
            
            # Get feature definitions
            num_features = self.feature_definitions[decision_type]['numerical']
            cat_features = self.feature_definitions[decision_type]['categorical']
            
            # Generate numerical features
            X_numerical = []
            for feature in num_features:
                if feature == 'credit_score':
                    values = np.random.normal(650, 100, n_samples)
                    values = np.clip(values, 300, 850)
                elif feature == 'income':
                    values = np.random.lognormal(10.5, 0.5, n_samples)
                    values = np.clip(values, 20000, 200000)
                elif feature == 'debt_to_income':
                    values = np.random.beta(2, 5, n_samples)
                    values = np.clip(values, 0, 1)
                elif feature in ['age', 'employment_length', 'credit_history_length']:
                    values = np.random.gamma(2, 5, n_samples)
                    values = np.clip(values, 0, 50)
                elif feature in ['loan_amount', 'current_limit']:
                    values = np.random.lognormal(9, 0.8, n_samples)
                    values = np.clip(values, 1000, 100000)
                elif feature == 'num_credit_lines':
                    values = np.random.poisson(5, n_samples)
                    values = np.clip(values, 1, 20)
                elif feature == 'payment_history':
                    values = np.random.beta(8, 2, n_samples)
                    values = np.clip(values, 0, 1)
                elif feature == 'account_age':
                    values = np.random.gamma(3, 2, n_samples)
                    values = np.clip(values, 0, 30)
                elif feature == 'delinquencies':
                    values = np.random.poisson(0.5, n_samples)
                    values = np.clip(values, 0, 10)
                elif feature == 'credit_utilization':
                    values = np.random.beta(3, 3, n_samples)
                    values = np.clip(values, 0, 1)
                elif feature == 'transaction_amount':
                    values = np.random.lognormal(6, 1.5, n_samples)
                    values = np.clip(values, 1, 10000)
                elif feature == 'transaction_frequency':
                    values = np.random.poisson(3, n_samples)
                    values = np.clip(values, 0, 20)
                elif feature == 'avg_transaction_amount':
                    values = np.random.lognormal(5.5, 1, n_samples)
                    values = np.clip(values, 10, 5000)
                elif feature == 'time_since_last_transaction':
                    values = np.random.exponential(2, n_samples)
                    values = np.clip(values, 0, 30)
                else:
                    values = np.random.normal(0, 1, n_samples)
                
                X_numerical.append(values)
            
            X_numerical = np.array(X_numerical).T
            
            # Generate categorical features
            X_categorical = []
            for feature in cat_features:
                categories = self._get_sample_categories(feature)
                values = np.random.choice(categories, n_samples)
                
                # Encode categorical values
                encoder = LabelEncoder()
                encoded_values = encoder.fit_transform(values)
                X_categorical.append(encoded_values)
            
            X_categorical = np.array(X_categorical).T if X_categorical else np.empty((n_samples, 0))
            
            # Combine features
            X = np.hstack([X_numerical, X_categorical])
            
            # Generate target variable based on features
            y = self._generate_target(X, decision_type, num_features)
            
            # Combine feature names
            feature_names = num_features + cat_features
            
            return X, y, feature_names
            
        except Exception as e:
            logger.error(f"Error generating synthetic data: {str(e)}")
            # Return minimal data as fallback
            return np.random.rand(100, 5), np.random.choice([0, 1], 100), ['feature_1', 'feature_2', 'feature_3', 'feature_4', 'feature_5']
    
    def _get_sample_categories(self, feature: str) -> List[str]:
        """Get sample categories for a categorical feature"""
        categories = {
            'home_ownership': ['own', 'rent', 'mortgage', 'other'],
            'purpose': ['debt_consolidation', 'home_improvement', 'major_purchase', 'other', 'medical', 'education'],
            'state': ['CA', 'NY', 'TX', 'FL', 'IL', 'PA', 'OH', 'GA', 'NC', 'MI'],
            'zip_code': ['90210', '10001', '77001', '33101', '60601', '19101', '44101', '30301'],
            'account_type': ['checking', 'savings', 'credit_card', 'loan'],
            'customer_segment': ['premium', 'standard', 'basic', 'new'],
            'region': ['northeast', 'south', 'midwest', 'west', 'southwest'],
            'transaction_type': ['purchase', 'withdrawal', 'transfer', 'payment'],
            'merchant_category': ['retail', 'restaurant', 'gas', 'grocery', 'entertainment', 'travel'],
            'device_type': ['mobile', 'desktop', 'tablet', 'atm'],
            'location': ['online', 'in_store', 'atm', 'phone']
        }
        
        return categories.get(feature, ['unknown'])
    
    def _generate_target(self, X: np.ndarray, decision_type: str, numerical_features: List[str]) -> np.ndarray:
        """Generate target variable based on features"""
        try:
            n_samples = X.shape[0]
            
            if decision_type == 'loan_approval':
                # Use credit score and debt-to-income ratio as main factors
                credit_score_idx = numerical_features.index('credit_score')
                debt_to_income_idx = numerical_features.index('debt_to_income')
                
                credit_score_factor = X[:, credit_score_idx] / 850  # Normalize to 0-1
                debt_to_income_factor = 1 - X[:, debt_to_income_idx]  # Invert (lower is better)
                
                # Combine factors with noise
                probability = 0.3 * credit_score_factor + 0.4 * debt_to_income_factor + 0.3 * np.random.random(n_samples)
                
            elif decision_type == 'credit_limit':
                # Use income and credit score
                income_idx = numerical_features.index('income')
                credit_score_idx = numerical_features.index('credit_score')
                
                income_factor = np.log1p(X[:, income_idx]) / np.log1p(200000)  # Normalize log income
                credit_score_factor = X[:, credit_score_idx] / 850
                
                probability = 0.5 * income_factor + 0.4 * credit_score_factor + 0.1 * np.random.random(n_samples)
                
            elif decision_type == 'risk_assessment':
                # Use credit score and payment history
                credit_score_idx = numerical_features.index('credit_score')
                payment_history_idx = numerical_features.index('payment_history')
                
                credit_score_factor = X[:, credit_score_idx] / 850
                payment_factor = X[:, payment_history_idx]
                
                probability = 0.6 * credit_score_factor + 0.3 * payment_factor + 0.1 * np.random.random(n_samples)
                
            elif decision_type == 'fraud_detection':
                # Use transaction amount and frequency
                amount_idx = numerical_features.index('transaction_amount')
                frequency_idx = numerical_features.index('transaction_frequency')
                
                amount_factor = np.log1p(X[:, amount_idx]) / 10  # Higher amounts are riskier
                frequency_factor = X[:, frequency_idx] / 20  # Higher frequency is riskier
                
                probability = 0.4 * amount_factor + 0.3 * frequency_factor + 0.3 * np.random.random(n_samples)
                
            else:
                # Default: random with slight bias
                probability = 0.6 + 0.2 * np.random.random(n_samples)
            
            # Convert to binary target
            y = (probability > 0.5).astype(int)
            
            return y
            
        except Exception as e:
            logger.error(f"Error generating target variable: {str(e)}")
            return np.random.choice([0, 1], len(X))
    
    def make_decision(self, decision_type: str, input_data: Dict[str, Any], user_id: str) -> Dict[str, Any]:
        """Make an AI decision"""
        try:
            if decision_type not in self.models:
                raise ValueError(f"Unknown decision type: {decision_type}")
            
            model = self.models[decision_type]
            metadata = self.model_metadata[decision_type]
            
            # Preprocess input data
            X_processed = self._preprocess_input(input_data, decision_type)
            
            # Make prediction
            start_time = datetime.now()
            prediction_proba = model.predict_proba(X_processed)[0]
            prediction = model.predict(X_processed)[0]
            processing_time = (datetime.now() - start_time).total_seconds() * 1000  # Convert to milliseconds
            
            # Get feature importance if available
            feature_importance = {}
            if hasattr(model, 'feature_importances_'):
                for i, feature in enumerate(metadata['feature_names']):
                    feature_importance[feature] = float(model.feature_importances_[i])
            
            # Determine outcome based on prediction
            outcome_map = {
                'loan_approval': {0: 'rejected', 1: 'approved'},
                'credit_limit': {0: 'no_change', 1: 'increase'},
                'risk_assessment': {0: 'high_risk', 1: 'low_risk'},
                'fraud_detection': {0: 'legitimate', 1: 'fraudulent'}
            }
            
            outcome = outcome_map.get(decision_type, {0: 'negative', 1: 'positive'}).get(prediction, 'unknown')
            
            # Create result
            result = {
                'decision_id': str(uuid.uuid4()),
                'decision_type': decision_type,
                'model_name': f"{decision_type}_model",
                'model_version': '1.0.0',
                'outcome': outcome,
                'confidence': float(prediction_proba[1]),  # Confidence in positive class
                'processing_time_ms': int(processing_time),
                'feature_importance': feature_importance,
                'input_features': input_data,
                'metadata': {
                    'user_id': user_id,
                    'model_type': metadata['model_type'],
                    'feature_count': len(metadata['feature_names']),
                    'prediction_timestamp': datetime.now(timezone.utc).isoformat()
                }
            }
            
            return result
            
        except Exception as e:
            logger.error(f"Error making decision: {str(e)}")
            return self._generate_fallback_decision(decision_type, input_data, user_id)
    
    def _preprocess_input(self, input_data: Dict[str, Any], decision_type: str) -> np.ndarray:
        """Preprocess input data for model prediction"""
        try:
            metadata = self.model_metadata[decision_type]
            numerical_features = metadata['numerical_features']
            categorical_features = metadata['categorical_features']
            encoders = self.encoders[decision_type]
            scaler = self.scalers[decision_type]
            
            # Extract numerical features
            numerical_values = []
            for feature in numerical_features:
                value = input_data.get(feature, 0)
                
                # Handle missing values
                if value is None:
                    value = 0
                
                # Convert to float
                try:
                    numerical_values.append(float(value))
                except (ValueError, TypeError):
                    numerical_values.append(0.0)
            
            # Extract categorical features
            categorical_values = []
            for feature in categorical_features:
                value = input_data.get(feature, 'unknown')
                
                # Encode categorical value
                encoder = encoders.get(feature)
                if encoder and value in encoder.classes_:
                    encoded_value = encoder.transform([value])[0]
                else:
                    # Handle unknown categories
                    encoded_value = 0
                
                categorical_values.append(encoded_value)
            
            # Combine features
            X = np.array(numerical_values + categorical_values).reshape(1, -1)
            
            # Scale numerical features
            if len(numerical_features) > 0 and scaler:
                X[:, :len(numerical_features)] = scaler.transform(X[:, :len(numerical_features)])
            
            return X
            
        except Exception as e:
            logger.error(f"Error preprocessing input: {str(e)}")
            # Return default features as fallback
            return np.zeros((1, len(numerical_features) + len(categorical_features)))
    
    def _generate_fallback_decision(self, decision_type: str, input_data: Dict[str, Any], user_id: str) -> Dict[str, Any]:
        """Generate fallback decision when model fails"""
        try:
            # Use simple rule-based logic as fallback
            credit_score = input_data.get('credit_score', 650)
            income = input_data.get('income', 50000)
            debt_to_income = input_data.get('debt_to_income', 0.3)
            
            # Simple decision logic
            if decision_type == 'loan_approval':
                if credit_score > 700 and debt_to_income < 0.4:
                    outcome = 'approved'
                    confidence = 0.85
                elif credit_score > 600 and debt_to_income < 0.5:
                    outcome = 'approved'
                    confidence = 0.70
                else:
                    outcome = 'rejected'
                    confidence = 0.80
            
            elif decision_type == 'credit_limit':
                if credit_score > 750 and income > 80000:
                    outcome = 'increase'
                    confidence = 0.90
                else:
                    outcome = 'no_change'
                    confidence = 0.75
            
            elif decision_type == 'risk_assessment':
                if credit_score > 700 and debt_to_income < 0.3:
                    outcome = 'low_risk'
                    confidence = 0.85
                else:
                    outcome = 'high_risk'
                    confidence = 0.80
            
            elif decision_type == 'fraud_detection':
                # Simple fraud detection based on amount
                amount = input_data.get('transaction_amount', 100)
                if amount > 5000:
                    outcome = 'fraudulent'
                    confidence = 0.60
                else:
                    outcome = 'legitimate'
                    confidence = 0.95
            
            else:
                outcome = 'unknown'
                confidence = 0.50
            
            return {
                'decision_id': str(uuid.uuid4()),
                'decision_type': decision_type,
                'model_name': f"{decision_type}_fallback",
                'model_version': '1.0.0',
                'outcome': outcome,
                'confidence': confidence,
                'processing_time_ms': 10,
                'feature_importance': {
                    'credit_score': 0.4,
                    'income': 0.3,
                    'debt_to_income': 0.3
                },
                'input_features': input_data,
                'metadata': {
                    'user_id': user_id,
                    'model_type': 'rule_based_fallback',
                    'fallback_reason': 'Model prediction failed',
                    'prediction_timestamp': datetime.now(timezone.utc).isoformat()
                }
            }
            
        except Exception as e:
            logger.error(f"Error generating fallback decision: {str(e)}")
            # Ultimate fallback
            return {
                'decision_id': str(uuid.uuid4()),
                'decision_type': decision_type,
                'model_name': 'emergency_fallback',
                'model_version': '1.0.0',
                'outcome': 'pending_review',
                'confidence': 0.0,
                'processing_time_ms': 1,
                'feature_importance': {},
                'input_features': input_data,
                'metadata': {
                    'user_id': user_id,
                    'model_type': 'emergency_fallback',
                    'error': str(e),
                    'prediction_timestamp': datetime.now(timezone.utc).isoformat()
                }
            }
    
    def get_model_info(self, decision_type: str) -> Dict[str, Any]:
        """Get information about a specific model"""
        try:
            if decision_type not in self.model_metadata:
                raise ValueError(f"Unknown decision type: {decision_type}")
            
            metadata = self.model_metadata[decision_type].copy()
            model = self.models[decision_type]
            
            # Add model-specific information
            if hasattr(model, 'feature_importances_'):
                metadata['feature_importances'] = dict(zip(
                    metadata['feature_names'],
                    [float(imp) for imp in model.feature_importances_]
                ))
            
            if hasattr(model, 'n_estimators'):
                metadata['n_estimators'] = model.n_estimators
            
            if hasattr(model, 'max_depth'):
                metadata['max_depth'] = model.max_depth
            
            return metadata
            
        except Exception as e:
            logger.error(f"Error getting model info: {str(e)}")
            return {}
    
    def evaluate_model(self, decision_type: str, test_data: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Evaluate model performance"""
        try:
            if decision_type not in self.models:
                raise ValueError(f"Unknown decision type: {decision_type}")
            
            # Generate test data if not provided
            if test_data is None:
                X_test, y_test, _ = self._generate_synthetic_data(decision_type)
            else:
                # Process provided test data
                X_test = test_data.get('X')
                y_test = test_data.get('y')
                if X_test is None or y_test is None:
                    raise ValueError("Test data must contain 'X' and 'y' keys")
            
            model = self.models[decision_type]
            
            # Make predictions
            y_pred = model.predict(X_test)
            y_pred_proba = model.predict_proba(X_test)[:, 1]
            
            # Calculate metrics
            metrics = {
                'accuracy': accuracy_score(y_test, y_pred),
                'precision': precision_score(y_test, y_pred, average='binary'),
                'recall': recall_score(y_test, y_pred, average='binary'),
                'f1_score': f1_score(y_test, y_pred, average='binary'),
                'auc_score': roc_auc_score(y_test, y_pred_proba)
            }
            
            return {
                'decision_type': decision_type,
                'model_type': self.model_metadata[decision_type]['model_type'],
                'test_samples': len(X_test),
                'metrics': metrics,
                'evaluation_timestamp': datetime.now(timezone.utc).isoformat()
            }
            
        except Exception as e:
            logger.error(f"Error evaluating model: {str(e)}")
            return {
                'decision_type': decision_type,
                'error': str(e),
                'evaluation_timestamp': datetime.now(timezone.utc).isoformat()
            }
    
    def save_model(self, decision_type: str, filepath: str):
        """Save model to file"""
        try:
            if decision_type not in self.models:
                raise ValueError(f"Unknown decision type: {decision_type}")
            
            model_data = {
                'model': self.models[decision_type],
                'scaler': self.scalers[decision_type],
                'encoders': self.encoders[decision_type],
                'metadata': self.model_metadata[decision_type]
            }
            
            joblib.dump(model_data, filepath)
            logger.info(f"Model {decision_type} saved to {filepath}")
            
        except Exception as e:
            logger.error(f"Error saving model: {str(e)}")
    
    def load_model(self, decision_type: str, filepath: str):
        """Load model from file"""
        try:
            if not os.path.exists(filepath):
                raise FileNotFoundError(f"Model file not found: {filepath}")
            
            model_data = joblib.load(filepath)
            
            self.models[decision_type] = model_data['model']
            self.scalers[decision_type] = model_data['scaler']
            self.encoders[decision_type] = model_data['encoders']
            self.model_metadata[decision_type] = model_data['metadata']
            
            logger.info(f"Model {decision_type} loaded from {filepath}")
            
        except Exception as e:
            logger.error(f"Error loading model: {str(e)}")

if __name__ == '__main__':
    # Test the model manager
    model_manager = ModelManagerService()
    
    # Test making a decision
    test_input = {
        'credit_score': 750,
        'income': 85000,
        'debt_to_income': 0.25,
        'employment_length': 5,
        'age': 35,
        'home_ownership': 'own',
        'purpose': 'debt_consolidation',
        'state': 'CA'
    }
    
    result = model_manager.make_decision('loan_approval', test_input, 'test_user')
    print("Model Manager Service initialized successfully")
    print(f"Test decision result: {json.dumps(result, indent=2)}")
