let currentRole = 'customer';
let reviewBoardTickets = [];
let activeReviewBoardRow = null;
let selectedModelGlobal = null;

// Fallback feature definitions for static templates
const FALLBACK_FEATURE_DEFS = {
    loan_approval: {
        numerical: ['credit_score', 'income', 'debt_to_income', 'employment_length', 'age', 'loan_amount', 'credit_history_length', 'num_credit_lines'],
        categorical: ['home_ownership', 'purpose', 'state', 'zip_code']
    },
    credit_limit: {
        numerical: ['credit_score', 'income', 'debt_to_income', 'employment_length', 'age', 'current_limit', 'payment_history', 'account_age'],
        categorical: ['account_type', 'customer_segment', 'region']
    },
    risk_assessment: {
        numerical: ['credit_score', 'income', 'debt_to_income', 'employment_length', 'age', 'payment_history', 'delinquencies', 'credit_utilization'],
        categorical: ['account_type', 'customer_segment', 'region']
    },
    fraud_detection: {
        numerical: ['transaction_amount', 'transaction_frequency', 'account_age', 'avg_transaction_amount', 'time_since_last_transaction'],
        categorical: ['transaction_type', 'merchant_category', 'device_type', 'location']
    }
};

function initProfileInsights() {
    loadProfileInsights();
    setInterval(loadProfileInsights, 60 * 1000);
}

function showTrace(trace) {
    const panel = document.getElementById('tracePanel');
    const list = document.getElementById('traceList');
    if (!panel || !list) {
        return;
    }
    panel.style.display = trace.length ? '' : 'none';
    list.innerHTML = trace.map(item =>
        `<div class="list-group-item d-flex justify-content-between align-items-center">
            <span>${item.feature}</span>
            <span class="text-muted">${(item.weight * 100).toFixed(1)}%</span>
        </div>`
    ).join('');
}

function showReviewBoard() {
    const board = document.getElementById('governanceBoard');
    if (board) {
        board.style.display = '';
    }
    setupExportTemplateButtons();
    loadReviewBoardTickets();
    const modalElement = document.getElementById('reviewBoardModal');
    if (modalElement && window.bootstrap) {
        const modal = bootstrap.Modal.getOrCreateInstance
            ? bootstrap.Modal.getOrCreateInstance(modalElement)
            : new bootstrap.Modal(modalElement);
        modal.show();
    }
}

async function loadReviewBoardTickets(silent = false) {
    try {
        const response = await fetch('/api/profile/corrections');
        if (!response.ok) {
            throw new Error('Unable to fetch review board tickets');
        }
        const tickets = await response.json();
        reviewBoardTickets = Array.isArray(tickets) ? tickets : [];
        updateReviewBoardSummary(reviewBoardTickets);
        renderReviewBoardTable(!silent);
    } catch (error) {
        console.error('Review board load failed', error);
        const table = document.getElementById('reviewBoardTable');
        if (table) {
            table.innerHTML = '<tr><td colspan="4" class="text-center text-muted py-4">Unable to load review tickets.</td></tr>';
        }
        const detail = document.getElementById('reviewTicketDetail');
        if (detail) {
            detail.innerHTML = '<p class="text-muted mb-0">Review board data is currently unavailable.</p>';
        }
        const summary = document.getElementById('reviewBoardSummary');
        if (summary) {
            summary.textContent = 'Unable to synchronize review board tickets.';
        }
        const footerMeta = document.getElementById('reviewBoardFooterMeta');
        if (footerMeta) {
            footerMeta.textContent = 'Review board sync failed.';
        }
    }
}

function renderReviewBoardTable(autoSelectFirst = false) {
    const table = document.getElementById('reviewBoardTable');
    if (!table) {
        return;
    }
    if (!reviewBoardTickets.length) {
        table.innerHTML = '<tr><td colspan="4" class="text-center text-muted py-4">No tickets found.</td></tr>';
        renderReviewTicketDetail();
        return;
    }
    table.innerHTML = reviewBoardTickets.map((ticket, index) => `
        <tr data-index="${index}" class="review-board-row" role="button">
            <td>
                <div class="fw-semibold">${ticket.id || `RB-${index + 1}`}</div>
                <small class="text-muted">${ticket.description || ticket.reason || 'AI profile review'}</small>
            </td>
            <td>${formatStatusBadge(ticket.status)}</td>
            <td>${ticket.owner || ticket.reviewer || 'Unassigned'}</td>
            <td>${ticket.updated_at || ticket.created_at || '—'}</td>
        </tr>
    `).join('');

    table.querySelectorAll('tr[data-index]').forEach(row => {
        row.addEventListener('click', () => {
            const index = parseInt(row.dataset.index, 10);
            selectReviewTicket(index, row);
        });
    });

    if (autoSelectFirst) {
        const firstRow = table.querySelector('tr[data-index]');
        if (firstRow) {
            selectReviewTicket(parseInt(firstRow.dataset.index, 10), firstRow);
        }
    }
}

function formatStatusBadge(status = 'pending') {
    const color = getStatusColor(status);
    return `<span class="badge bg-${color} text-uppercase">${status || 'pending'}</span>`;
}

function getStatusColor(status = '') {
    const normalized = status.toLowerCase();
    if (normalized.includes('resolved')) {
        return 'success';
    }
    if (normalized.includes('critical') || normalized.includes('escalated')) {
        return 'danger';
    }
    if (normalized.includes('investigating')) {
        return 'info';
    }
    if (normalized.includes('open') || normalized.includes('pending')) {
        return 'warning';
    }
    return 'secondary';
}

function updateReviewBoardSummary(tickets = []) {
    const summary = document.getElementById('reviewBoardSummary');
    const footerMeta = document.getElementById('reviewBoardFooterMeta');
    const syncLabel = document.getElementById('reviewBoardSync');
    const subtitle = document.getElementById('reviewBoardSubtitle');

    const total = tickets.length;
    const openTickets = tickets.filter(ticket => {
        const status = (ticket.status || '').toLowerCase();
        return !status || status.includes('open') || status.includes('investigating');
    }).length;
    const escalated = tickets.filter(ticket => (ticket.status || '').toLowerCase().includes('escalated')).length;
    const resolved = tickets.filter(ticket => (ticket.status || '').toLowerCase().includes('resolved')).length;
    const timestamp = new Date().toLocaleTimeString();

    if (summary) {
        summary.innerHTML = `
            <span class="me-3"><strong>${openTickets}</strong> active</span>
            <span class="me-3 text-danger"><strong>${escalated}</strong> escalated</span>
            <span class="text-success"><strong>${resolved}</strong> resolved today</span>
        `;
    }
    const metaCopy = `Last synced ${timestamp} • ${total} ticket${total === 1 ? '' : 's'}`;
    if (footerMeta) {
        footerMeta.textContent = metaCopy;
    }
    if (syncLabel) {
        syncLabel.textContent = metaCopy;
    }
    if (subtitle) {
        subtitle.textContent = total ? 'Select a ticket to review investigator context.' : 'No open tickets at the moment.';
    }
}

function selectReviewTicket(index, rowElement) {
    const ticket = reviewBoardTickets[index];
    if (!ticket) {
        return;
    }
    if (activeReviewBoardRow) {
        activeReviewBoardRow.classList.remove('table-active');
    }
    if (rowElement) {
        rowElement.classList.add('table-active');
        activeReviewBoardRow = rowElement;
    }
    renderReviewTicketDetail(ticket);
}

function renderReviewTicketDetail(ticket = null) {
    const container = document.getElementById('reviewTicketDetail');
    if (!container) {
        return;
    }
    if (!ticket) {
        container.innerHTML = '<p class="text-muted mb-0">No tickets available. Refresh to pull the latest review board activity.</p>';
        return;
    }
    const timeline = `
        <dl class="row mb-0 small">
            <dt class="col-5">Opened</dt><dd class="col-7">${ticket.created_at || '—'}</dd>
            <dt class="col-5">Updated</dt><dd class="col-7">${ticket.updated_at || '—'}</dd>
            <dt class="col-5">Owner</dt><dd class="col-7">${ticket.owner || ticket.reviewer || 'Unassigned'}</dd>
            <dt class="col-5">Customer</dt><dd class="col-7">${ticket.user || ticket.customer || '—'}</dd>
        </dl>
    `;
    container.innerHTML = `
        <div class="d-flex justify-content-between align-items-start">
            <div>
                <h6 class="fw-bold mb-1">Ticket ${ticket.id || '—'}</h6>
                ${formatStatusBadge(ticket.status || 'pending')}
            </div>
            <button class="btn btn-sm btn-outline-dark" onclick="viewAuditLogs()">
                <i class="fas fa-clipboard-list me-1"></i>Audit Trail
            </button>
        </div>
        <p class="small text-muted mb-2">${ticket.description || ticket.reason || 'AI profile review requested.'}</p>
        <div class="border rounded p-2 bg-white mb-3">
            ${timeline}
        </div>
        <div class="mt-3 d-flex flex-wrap gap-2">
            <button class="btn btn-success btn-sm" onclick="markReviewTicketResolved('${ticket.id || ''}')">
                <i class="fas fa-check me-1"></i>Mark Resolved
            </button>
            <button class="btn btn-outline-danger btn-sm" onclick="escalateReviewTicket('${ticket.id || ''}')">
                <i class="fas fa-flag me-1"></i>Escalate
            </button>
        </div>
    `;
}

function markReviewTicketResolved(ticketId) {
    if (!ticketId) {
        return;
    }
    fetch(`/api/profile/corrections/${ticketId}/resolve`, { method: 'POST' })
        .then(response => {
            if (!response.ok) {
                throw new Error('resolve_failed');
            }
            return response.json().catch(() => ({}));
        })
        .then(() => {
            if (window.trustai) {
                window.trustai.showAlert('Ticket resolved.', 'success');
            }
            loadReviewBoardTickets(true);
        })
        .catch(() => {
            simulateReviewTicketUpdate(ticketId, {
                status: 'resolved',
                updated_at: new Date().toISOString()
            });
            if (window.trustai) {
                window.trustai.showAlert('Ticket resolved locally (mock).', 'info');
            }
        });
}

function escalateReviewTicket(ticketId) {
    if (!ticketId) {
        return;
    }
    fetch(`/api/profile/corrections/${ticketId}/escalate`, { method: 'POST' })
        .then(response => {
            if (!response.ok) {
                throw new Error('escalate_failed');
            }
            return response.json().catch(() => ({}));
        })
        .then(() => {
            if (window.trustai) {
                window.trustai.showAlert('Ticket escalated.', 'warning');
            }
            loadReviewBoardTickets(true);
        })
        .catch(() => {
            simulateReviewTicketUpdate(ticketId, {
                status: 'escalated',
                updated_at: new Date().toISOString()
            });
            if (window.trustai) {
                window.trustai.showAlert('Ticket escalation simulated locally.', 'warning');
            }
        });
}

function simulateReviewTicketUpdate(ticketId, updates = {}) {
    let updatedTicket = null;
    reviewBoardTickets = reviewBoardTickets.map(ticket => {
        if (ticket.id === ticketId) {
            updatedTicket = { ...ticket, ...updates };
            return updatedTicket;
        }
        return ticket;
    });
    if (updatedTicket) {
        updateReviewBoardSummary(reviewBoardTickets);
        renderReviewBoardTable(false);
        const newIndex = reviewBoardTickets.findIndex(ticket => ticket.id === ticketId);
        const newRow = document.querySelector(`#reviewBoardTable tr[data-index="${newIndex}"]`);
        if (newRow) {
            selectReviewTicket(newIndex, newRow);
        } else {
            renderReviewTicketDetail(updatedTicket);
        }
    }
}

function setupExportTemplateButtons() {
    const container = document.getElementById('exportTemplateButtons');
    if (!container || !window.trustai) {
        return;
    }
    container.innerHTML = '';
    const templates = [
        { label: 'Governance PDF', template: 'governance_pdf' },
        { label: 'Consent CSV', template: 'consent_csv' },
        { label: 'Operations JSON', template: 'ops_json' }
    ];
    templates.forEach(item => {
        const button = document.createElement('button');
        button.className = 'btn btn-outline-secondary btn-sm';
        button.textContent = item.label;
        button.addEventListener('click', () => window.trustai.exportData(item.template));
        container.appendChild(button);
    });
}

async function fetchCorrectionLogs() {
    try {
        const response = await fetch('/api/profile/corrections');
        if (!response.ok) throw new Error('Unable to fetch corrections');
        const logs = await response.json();
        const container = document.getElementById('correctionLogArea');
        if (container && Array.isArray(logs) && logs.length) {
            container.innerHTML = '<h6 class="text-muted mb-2">Correction history</h6>' +
                logs.map(log => `<div class="small mb-1">${log.status} - ${log.updated_at || log.created_at}</div>`).join('');
        }
    } catch (error) {
        console.error('Correction logs failed', error);
    }
}

async function loadProfileInsights() {
    try {
        const response = await fetch('/api/profile/insights');
        if (!response.ok) {
            throw new Error('Unable to load profile insights.');
        }
        const insight = await response.json();
        document.getElementById('profileInsightSummary').textContent = insight.summary || 'No insights available.';
        document.getElementById('profileInsightConfidence').textContent = insight.confidence ? `Confidence: ${Math.round(insight.confidence * 100)}%` : '';
        const flag = document.getElementById('profileInsightFlag');
        if (flag) {
            flag.textContent = insight.flag || 'Stable';
            flag.className = `badge ${insight.flag === 'Review' ? 'bg-warning text-dark' : 'bg-primary'}`;
        }
    } catch (error) {
        console.error('Failed to load profile insights', error);
        const summary = document.getElementById('profileInsightSummary');
        if (summary) {
            summary.textContent = 'Profile insights unavailable.';
        }
    }
}

function requestProfileCorrection() {
    if (window.trustai) {
        window.trustai.showLoading();
        fetch('/api/profile/corrections', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ reason: 'User requested review of AI profile inference.' })
        })
            .then(response => response.json())
            .then(result => {
                window.trustai.showAlert(result.message || 'Correction request submitted. A human reviewer will follow up.', 'success');
                // Refresh review board to pick up new correction tickets
                try { loadReviewBoardTickets(true); } catch (e) { console.warn('Unable to refresh review board after correction request', e); }
            })
            .catch(err => {
                console.error('Correction request failed', err);
                window.trustai.showAlert('Unable to submit correction request right now.', 'danger');
            })
            .finally(() => window.trustai.hideLoading());
    }
}

function initNotificationPoller() {
    pollNotifications();
    setInterval(pollNotifications, 30 * 1000);
}

async function pollNotifications() {
    try {
        const response = await fetch('/api/notifications');
        if (!response.ok) {
            throw new Error('Failed to fetch notifications');
        }
        const notifications = await response.json();
        const tray = document.getElementById('notificationTray');
        if (!tray || !notifications.length) {
            return;
        }
        ticketNotificationStream(notifications);
    } catch (error) {
        console.error('Notification poll failed:', error);
    }
}

function ticketNotificationStream(notifications) {
    const tray = document.getElementById('notificationTray');
    const stream = document.getElementById('notificationStream');
    if (!tray || !stream) {
        return;
    }
    tray.innerHTML = '';
    stream.innerHTML = '';
    const pulse = document.createElement('span');
    pulse.className = 'badge bg-danger rounded-circle ms-1';
    pulse.innerHTML = '&nbsp;';
    tray.appendChild(pulse);
    notifications.slice(0, 4).forEach(notification => {
        const color = notification.type === 'bias' ? 'warning' : notification.type === 'security' ? 'danger' : 'primary';
        const badge = document.createElement('div');
        badge.className = `alert alert-${color} alert-dismissible fade show p-2 m-0`;
        badge.style.flex = '1';
        badge.innerHTML = `${notification.message || 'AI action'}<br><small>${notification.detail || ''}</small>`;
        const button = document.createElement('button');
        button.className = 'btn-close btn-sm float-end';
        button.onclick = () => dismissNotification(notification.id, badge);
        badge.appendChild(button);
        if (notification.type === 'bias') {
            const actionBtn = document.createElement('button');
            actionBtn.className = 'btn btn-sm btn-outline-dark mt-1';
            actionBtn.textContent = 'Investigate Bias';
            actionBtn.addEventListener('click', () => viewAuditLogs());
            badge.appendChild(actionBtn);
        }
        stream.appendChild(badge);
    });
}

function dismissNotification(id, badge) {
    fetch(`/api/notifications/${id}/ack`, { method: 'POST' })
        .then(() => badge.remove())
        .catch(() => badge.classList.add('border')); 
}

function buildExplanationSummary(explanation = {}) {
    const outcome = explanation.outcome || 'Outcome unavailable';
    const confidence = explanation.confidence_score != null ? `${Math.round(explanation.confidence_score * 100)}% confidence` : 'confidence data unavailable';
    const rationale = explanation.reason || explanation.explanation_text || 'The system could not generate a rationale.';
    return {
        heading: `${outcome} (${confidence})`,
        body: rationale
    };
}

document.addEventListener('DOMContentLoaded', function () {
    const navMenu = document.getElementById('navMenu');
    if (!navMenu || !window.trustai) {
        return;
    }

    const user = window.trustai.user || {};
    currentRole = user.role || 'customer';
    const role = currentRole;

    const userNameElement = document.getElementById('userName');
    if (userNameElement && user.firstName && user.lastName) {
        userNameElement.textContent = user.firstName + ' ' + user.lastName;
    }

    const userRoleElement = document.getElementById('userRole');
    if (userRoleElement) {
        userRoleElement.textContent = role;
    }

    const baseNavItems = [
        { id: 'nav-dashboard', label: 'Dashboard', href: '#top' },
        { id: 'nav-decisions', label: 'AI Decisions', href: '#decisionsSection' },
        { id: 'nav-consents', label: 'Consent Management', href: '#consentCard' },
        { id: 'nav-analytics', label: 'Analytics', href: '#chartsCard' }
    ];

    const adminNavItems = [
        { id: 'nav-audit', label: 'Audit Logs', href: '#auditLogsModal' },
        { id: 'nav-bias', label: 'Bias Monitoring', href: '#biasAlertsCard' },
        { id: 'nav-models', label: 'AI Models', href: '#decisionSimulatorCard' }
    ];

    function createNavItem(item, active) {
        const li = document.createElement('li');
        li.className = 'nav-item';
        const a = document.createElement('a');
        a.className = 'nav-link' + (active ? ' active' : '');
        a.href = item.href;
        a.id = item.id;
        a.textContent = item.label;
        li.appendChild(a);
        return li;
    }

    navMenu.innerHTML = '';
    baseNavItems.forEach(function (item, index) {
        navMenu.appendChild(createNavItem(item, index === 0));
    });

    if (role === 'admin' || role === 'compliance_officer') {
        adminNavItems.forEach(function (item) {
            navMenu.appendChild(createNavItem(item, false));
        });
        const adminPanelCard = document.getElementById('adminPanelCard');
        if (adminPanelCard) {
            adminPanelCard.style.display = '';
        }
        const governanceCard = document.getElementById('governanceBoard');
        if (governanceCard) {
            governanceCard.style.display = '';
            loadReviewBoardTickets(true);
        }
    }

    setupRoleActions(role);
    initStatsCards();
    initModelSelection();
    loadDecisions();
    initCharts();
    initConsentManagement();
    initBiasAlerts(role);
    initAdminSections(role);
    initProfileInsights();
    initNotificationPoller();
});

function setupRoleActions(role) {
    const roleCard = document.getElementById('roleActionsCard');
    const container = document.getElementById('roleActionsContainer');
    if (!roleCard || !container) {
        return;
    }
    roleCard.style.display = '';
    container.innerHTML = '';
    fetchCorrectionLogs();
    const buttons = [];
    if (role === 'customer') {
        buttons.push({ label: 'Explain My Profile', action: () => document.getElementById('profileInsightsCard').scrollIntoView(), style: 'outline-primary' });
        buttons.push({ label: 'Notification Preferences', action: showNotificationPreferences, style: 'outline-secondary' });
        buttons.push({ label: 'Correction Ticket History', action: () => document.getElementById('correctionLogArea').scrollIntoView(), style: 'outline-info' });
    }
    if (role === 'customer_service') {
        buttons.push({ label: 'Approve Consent', action: approveConsent, style: 'outline-success' });
        buttons.push({ label: 'Contact Customer', action: contactCustomer, style: 'outline-warning' });
    }
    if (role === 'admin' || role === 'compliance_officer') {
        buttons.push({ label: 'Override Latest Decision', action: () => overrideDecision(null), style: 'outline-danger' });
        buttons.push({ label: 'AI Review Board', action: showReviewBoard, style: 'outline-info' });
    }
    // Add the "Request Correction" button for all roles
    buttons.push({ label: 'Request Correction', action: requestProfileCorrection, style: 'outline-primary' });
    
    buttons.forEach(btn => {
        const button = document.createElement('button');
        button.className = `btn btn-sm btn-${btn.style} me-2`; 
        button.textContent = btn.label;
        button.addEventListener('click', btn.action);
        container.appendChild(button);
    });
}

function showNotificationPreferences() {
    const preferences = ['bias', 'security', 'data'];
    const dialog = document.createElement('div');
    dialog.className = 'p-3';
    dialog.innerHTML = '<h6 class="fw-bold">Notification Preferences</h6>' +
        preferences.map(type => `
            <div class="form-check form-switch">
                <input class="form-check-input" type="checkbox" id="notify-${type}" data-type="${type}" checked>
                <label class="form-check-label" for="notify-${type}">${type} alerts</label>
            </div>`).join('');
    document.body.appendChild(dialog);
    dialog.querySelectorAll('input[type="checkbox"]').forEach(input => {
        input.addEventListener('change', () => updateNotificationPreference(input.dataset.type, input.checked));
    });
}

function updateNotificationPreference(type, enabled) {
    fetch('/api/notifications/preferences', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type, enabled })
    }).catch(err => console.error('Preference update failed', err));
}

function approveConsent() {
    fetch('/api/consent/review', { method: 'POST' })
        .then(() => window.trustai.showAlert('Consent approved.', 'success'))
        .catch(() => window.trustai.showAlert('Consent approval failed.', 'danger'));
}

function contactCustomer() {
    fetch('/api/messages', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ note: 'Customer service follow-up required.' }) })
        .then(() => window.trustai.showAlert('Customer notified.', 'success'))
        .catch(() => window.trustai.showAlert('Unable to contact customer.', 'danger'));
}

function overrideDecision(decisionId) {
    // Prompt admin for override details and call the API with required fields
    (async function () {
        try {
            let targetId = decisionId;

            // If no decisionId provided, attempt to fetch the most recent decision
            if (!targetId) {
                try {
                    const resp = await fetch('/api/decisions?page=1&per_page=1');
                    if (resp.ok) {
                        const data = await resp.json();
                        const first = (data.decisions && data.decisions[0]) || null;
                        if (first && first.id) {
                            targetId = first.id;
                        }
                    }
                } catch (e) {
                    console.warn('Could not fetch latest decision for override', e);
                }
            }

            if (!targetId) {
                if (window.trustai) window.trustai.showAlert('No decision available to override.', 'warning');
                return;
            }

            const newOutcome = prompt('Enter the new outcome (e.g. approved, denied, review):');
            if (!newOutcome) {
                if (window.trustai) window.trustai.showAlert('Override cancelled: no outcome provided.', 'info');
                return;
            }

            const reason = prompt('Provide a reason for the override (required):');
            if (!reason) {
                if (window.trustai) window.trustai.showAlert('Override cancelled: reason is required.', 'warning');
                return;
            }

            const payload = {
                decisionId: targetId,
                newOutcome: newOutcome,
                reason: reason
            };

            const response = await fetch('/api/decisions/override', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            });

            const result = await response.json().catch(() => ({}));

            if (!response.ok) {
                const message = result.error || result.message || 'Override failed';
                if (window.trustai) window.trustai.showAlert(message, 'danger');
                return;
            }

            if (window.trustai) window.trustai.showAlert(result.message || 'Decision override applied.', 'success');

            // Refresh decisions list and review board if present
            try { loadDecisions(); } catch (e) { /* ignore */ }
            try { loadReviewBoardTickets(true); } catch (e) { /* ignore */ }

        } catch (err) {
            console.error('Override failed', err);
            if (window.trustai) window.trustai.showAlert('Override failed.', 'danger');
        }
    })();
}

function initStatsCards() {
    const statsContainer = document.getElementById('statsCards');
    if (!statsContainer) {
        return;
    }

    statsContainer.innerHTML = '';

    const cards = [
        { id: 'decisionCount', label: 'AI Decisions', icon: 'fas fa-robot', color: 'primary' },
        { id: 'consentCount', label: 'Active Consents', icon: 'fas fa-check-circle', color: 'success' },
        { id: 'fairnessScore', label: 'Fairness Score', icon: 'fas fa-chart-line', color: 'info' },
        { id: 'biasAlerts', label: 'Bias Alerts', icon: 'fas fa-exclamation-triangle', color: 'warning' }
    ];

    cards.forEach(function (card) {
        const col = document.createElement('div');
        col.className = 'col-md-3 mb-3';

        const cardDiv = document.createElement('div');
        cardDiv.className = 'card border-0 shadow-sm h-100';

        const body = document.createElement('div');
        body.className = 'card-body';

        const wrapper = document.createElement('div');
        wrapper.className = 'd-flex align-items-center';

        const iconWrapper = document.createElement('div');
        iconWrapper.className = 'flex-shrink-0';

        const iconCircle = document.createElement('div');
        iconCircle.className = 'stat-icon bg-' + card.color + ' bg-opacity-10 text-' + card.color + ' rounded-circle p-3';

        const icon = document.createElement('i');
        icon.className = card.icon + ' fa-lg';
        iconCircle.appendChild(icon);
        iconWrapper.appendChild(iconCircle);

        const textWrapper = document.createElement('div');
        textWrapper.className = 'flex-grow-1 ms-3';

        const label = document.createElement('h6');
        label.className = 'text-muted mb-1';
        label.textContent = card.label;

        const value = document.createElement('h3');
        value.className = 'fw-bold mb-0';
        value.id = card.id;
        value.textContent = '0';

        textWrapper.appendChild(label);
        textWrapper.appendChild(value);

        wrapper.appendChild(iconWrapper);
        wrapper.appendChild(textWrapper);
        body.appendChild(wrapper);
        cardDiv.appendChild(body);
        col.appendChild(cardDiv);
        statsContainer.appendChild(col);
    });

    if (window.trustai) {
        window.trustai.updateDashboardStats();
    }
}

function initAdminSections(role) {
    if (role !== 'admin' && role !== 'compliance_officer') {
        return;
    }

    const adminStatsContainer = document.getElementById('adminStatsCards');
    if (adminStatsContainer) {
        adminStatsContainer.innerHTML = '';
        const cards = [
            { id: 'totalUsers', label: 'Active Users', icon: 'fas fa-users', color: 'secondary' },
            { id: 'systemHealth', label: 'System Health', icon: 'fas fa-heartbeat', color: 'success' },
            { id: 'auditAlerts', label: 'Open Audit Alerts', icon: 'fas fa-bullhorn', color: 'danger' },
            { id: 'modelPerformance', label: 'Model Health', icon: 'fas fa-chart-pie', color: 'info' }
        ];

        cards.forEach(card => {
            const col = document.createElement('div');
            col.className = 'col-lg-3 mb-3';
            const cardDiv = document.createElement('div');
            cardDiv.className = 'card border-0 shadow-sm h-100';
            cardDiv.innerHTML = `
                <div class="card-body d-flex align-items-center">
                    <div class="stat-icon bg-${card.color} bg-opacity-10 text-${card.color} rounded-circle p-3 flex-shrink-0">
                        <i class="${card.icon} fa-lg"></i>
                    </div>
                    <div class="flex-grow-1 ms-3">
                        <h6 class="text-muted mb-1">${card.label}</h6>
                        <h3 class="fw-bold mb-0" id="${card.id}">0</h3>
                    </div>
                </div>`;
            col.appendChild(cardDiv);
            adminStatsContainer.appendChild(col);
        });

        refreshAdminStats();
        if (window.trustai) {
            window.trustai.updateDashboardStats = (async function (orig) {
                return async function () {
                    const stats = await orig.apply(this, arguments);
                    updateAdminStats(stats);
                    return stats;
                };
            })(window.trustai.updateDashboardStats.bind(window.trustai));
        }
    }

    const adminControls = document.querySelectorAll('[data-admin-action]');
    adminControls.forEach(control => {
        control.addEventListener('click', () => {
            const action = control.dataset.adminAction;
            if (action === 'export') {
                if (window.trustai) {
                    window.trustai.exportData('json');
                }
            }
            if (action === 'audit') {
                viewAuditLogs();
            }
            if (action === 'performance') {
                viewModelPerformance();
            }
        });
    });
}

function updateAdminStats(stats = {}) {
    const totalUsers = document.getElementById('totalUsers');
    if (totalUsers) {
        totalUsers.textContent = stats.totalUsers || '—';
    }
    const systemHealth = document.getElementById('systemHealth');
    if (systemHealth) {
        const status = (stats.systemHealth && stats.systemHealth.status) || 'Unknown';
        systemHealth.textContent = `${status} (${(stats.systemHealth && stats.systemHealth.responseTime) || '—'})`;
    }
    const auditAlerts = document.getElementById('auditAlerts');
    if (auditAlerts) {
        auditAlerts.textContent = stats.biasAlerts || stats.criticalAlerts || '0';
    }
    const modelPerformance = document.getElementById('modelPerformance');
    if (modelPerformance) {
        modelPerformance.textContent = (stats.fairnessScore || 0) + '%';
    }
}

async function initModelSelection() {
    const modelSelectionSection = document.getElementById('modelSelectionSection');
    if (currentRole === 'customer' && modelSelectionSection) {
        modelSelectionSection.style.display = 'none';
        return;
    }
    const simulatorCard = document.getElementById('decisionSimulatorCard');
    const form = document.getElementById('decisionForm');
    const modelCardsContainer = document.getElementById('modelCardsContainer');
    if (!simulatorCard || !form) {
        return;
    }

    let models = [];
    let modelFeatureDefs = {};

    // Try to fetch models from backend (optional)
    try {
        const response = await fetch('/api/models');
        if (response.ok) {
            models = await response.json();
        }
    } catch (err) {
        // ignore - we'll fallback to static cards
        models = [];
    }

    // If a dynamic model cards container exists, render cards there
    if (modelCardsContainer && models && models.length) {
        modelCardsContainer.innerHTML = '';
        models.forEach(model => {
            const card = document.createElement('div');
            card.className = 'card model-card mb-3';
            card.style.cursor = 'pointer';
            card.innerHTML = `
                <div class="card-body">
                    <h5 class="card-title">${model.label || model.decision_type}</h5>
                    <p class="card-text">${model.description || ''}</p>
                </div>
            `;
            card.addEventListener('click', function () {
                // Remove highlight from all cards
                modelCardsContainer.querySelectorAll('.model-card').forEach(c => c.classList.remove('border-primary', 'shadow'));
                card.classList.add('border-primary', 'shadow');
                selectedModelGlobal = model.decision_type;
                modelFeatureDefs = model.features || {};
                buildModelInputs(selectedModelGlobal, modelFeatureDefs);
                simulatorCard.style.display = '';
            });
            modelCardsContainer.appendChild(card);
        });
    } else {
        // Fallback: attach click handlers to existing static .model-card elements in template
        const staticCards = document.querySelectorAll('.model-card');
        staticCards.forEach(card => {
            card.addEventListener('click', function () {
                // Try to extract decisionType from inline onclick attribute if present
                let decisionType = null;
                const onclickAttr = card.getAttribute('onclick');
                if (onclickAttr) {
                    const m = onclickAttr.match(/['"](\w+_?\w*)['"]/);
                    if (m) decisionType = m[1];
                }
                // If not found, use text label
                if (!decisionType) {
                    const title = card.querySelector('.card-body h6, .card-body h5');
                    if (title) {
                        const txt = title.textContent.trim().toLowerCase().replace(/ /g, '_');
                        decisionType = txt;
                    }
                }

                selectModel(decisionType, card);
            });
        });

        async function selectModel(decisionType, cardElement = null) {
            if (!decisionType) return;
            // Remove highlight from all cards
            document.querySelectorAll('.model-card').forEach(c => c.classList.remove('border-primary', 'shadow'));
            if (cardElement) {
                cardElement.classList.add('border-primary', 'shadow');
            } else {
                // Try to find matching card and highlight
                const matching = Array.from(document.querySelectorAll('.model-card')).find(c => {
                    const onclick = c.getAttribute('onclick') || '';
                    if (onclick.includes(decisionType)) return true;
                    const title = c.querySelector('.card-body h6, .card-body h5');
                    if (title && title.textContent.toLowerCase().replace(/ /g,'_') === decisionType) return true;
                    return false;
                });
                if (matching) matching.classList.add('border-primary', 'shadow');
            }

            selectedModelGlobal = decisionType;
            let features = null;
            // Try to get features from backend
            try {
                const resp = await fetch('/api/models');
                if (resp.ok) {
                    const models = await resp.json();
                    const found = models.find(m => m.decision_type === decisionType);
                    if (found) features = found.features || null;
                }
            } catch (e) {
                // ignore
            }

            if (!features) {
                features = FALLBACK_FEATURE_DEFS[decisionType] || { numerical: [], categorical: [] };
            }

            buildModelInputs(decisionType, features);
            const simulatorCard = document.getElementById('decisionSimulatorCard');
            if (simulatorCard) simulatorCard.style.display = '';
        }
    }

    // Form submit uses global selectedModelGlobal
    form.addEventListener('submit', function (e) {
        e.preventDefault();
        if (!selectedModelGlobal || !window.trustai) {
            return;
        }
        const inputContainer = document.getElementById('modelInputFields');
        const inputs = inputContainer.querySelectorAll('input, select');
        const payload = {};
        inputs.forEach(function (input) {
            const name = input.name;
            let value = input.value;
            if (input.type === 'number') {
                value = input.value === '' ? null : Number(input.value);
            }
            payload[name] = value;
        });
        runDecision(selectedModelGlobal, payload);
    });
}

function buildModelInputs(decisionType, features) {
    const container = document.getElementById('modelInputFields');
    if (!container) {
        return;
    }

    // features: { numerical: [...], categorical: [...] }
    if (!features || (!features.numerical && !features.categorical)) {
        container.innerHTML = '<div class="alert alert-warning">No feature definitions available for this model.</div>';
        return;
    }

    container.innerHTML = '';

    const title = document.getElementById('simulatorTitle');
    if (title) {
        title.textContent = (decisionType.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase()) + ' Simulator');
    }

    const row = document.createElement('div');
    row.className = 'row g-3';

    (features.numerical || []).forEach(function (name) {
        const col = document.createElement('div');
        col.className = 'col-md-6';
        const group = document.createElement('div');
        group.className = 'mb-2';
        const label = document.createElement('label');
        label.className = 'form-label';
        label.setAttribute('for', name);
        label.textContent = name.replace(/_/g, ' ');
        const input = document.createElement('input');
        input.className = 'form-control';
        input.type = 'number';
        input.name = name;
        input.id = name;
        group.appendChild(label);
        group.appendChild(input);
        col.appendChild(group);
        row.appendChild(col);
    });

    (features.categorical || []).forEach(function (name) {
        const col = document.createElement('div');
        col.className = 'col-md-6';
        const group = document.createElement('div');
        group.className = 'mb-2';
        const label = document.createElement('label');
        label.className = 'form-label';
        label.setAttribute('for', name);
        label.textContent = name.replace(/_/g, ' ');
        const input = document.createElement('input');
        input.className = 'form-control';
        input.type = 'text';
        input.name = name;
        input.id = name;
        group.appendChild(label);
        group.appendChild(input);
        col.appendChild(group);
        row.appendChild(col);
    });

    container.appendChild(row);
}

function runDecision(decisionType, inputData) {
    fetch('/api/decisions/simulate', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            decision_type: decisionType,
            input_data: inputData
        })
    })
        .then(function (response) { return response.json(); })
        .then(function (data) {
            const resultContainer = document.getElementById('decisionResult');
            if (!resultContainer) {
                return;
            }
            resultContainer.style.display = '';
            const decision = data.decision || {};
            const explanation = data.explanation || {};
            const trace = data.trace || [];
            const biasAlerts = data.bias_alerts || [];
            showTrace(trace);
            resultContainer.innerHTML = '' +
                '<div class="alert alert-info mb-3">' +
                '<strong>Outcome:</strong> ' + (decision.outcome || 'N/A') +
                ' &nbsp; <strong>Confidence:</strong> ' + (decision.confidence_score != null ? Math.round(decision.confidence_score * 100) + '%' : 'N/A') +
                '</div>' +
                '<pre class="bg-light p-3 rounded small mb-2">' +
                JSON.stringify({ explanation: explanation, bias_alerts: biasAlerts }, null, 2) +
                '</pre>';
        })
        .catch(function (error) {
            console.error('Failed to run decision', error);
        });
}

function loadDecisions(page) {
    const tableBody = document.getElementById('decisionsTable');
    if (!tableBody) {
        return;
    }

    const currentPage = page || 1;

    fetch('/api/decisions?page=' + currentPage + '&per_page=10')
        .then(function (response) { return response.json(); })
        .then(function (data) {
            const decisions = data.decisions || [];
            if (!decisions.length) {
                tableBody.innerHTML = '<tr><td colspan="6" class="text-center text-muted">No decisions found</td></tr>';
                return;
            }
            tableBody.innerHTML = '';
            decisions.forEach(function (d) {
                const tr = document.createElement('tr');
                const createdAt = d.created_at || d.createdAt || '';
                const outcome = d.outcome || '';
                const confidence = d.confidence_score != null ? Math.round(d.confidence_score * 100) + '%' : '';
                tr.innerHTML = '' +
                    '<td>' + createdAt + '</td>' +
                    '<td>' + (d.decision_type || '') + '</td>' +
                    '<td>' + (d.model_name || '') + '</td>' +
                    '<td>' + outcome + '</td>' +
                    '<td>' + confidence + '</td>' +
                    '<td>' +
                        '<button class="btn btn-sm btn-outline-primary me-1" onclick="viewExplanation(\'' + d.id + '\')">Explain</button>' +
                        (currentRole === 'compliance_officer' || currentRole === 'admin' ? '<button class="btn btn-sm btn-outline-danger" onclick="overrideDecision(\'' + d.id + '\')">Override</button>' : '') +
                    '</td>';
                tableBody.appendChild(tr);
            });
        })
        .catch(function (error) {
            console.error('Failed to load decisions', error);
        });
}

function initCharts() {
    if (!window.Plotly) {
        return;
    }

    const fairnessElement = document.getElementById('fairnessChart');
    if (fairnessElement) {
        const data = [{
            x: ['Demographic Parity', 'Equal Opportunity', 'Predictive Parity', 'Overall Accuracy'],
            y: [92, 88, 94, 96],
            type: 'bar'
        }];
        const layout = {
            title: 'Fairness Metrics Overview',
            yaxis: { title: 'Score (%)', range: [0, 100] },
            margin: { t: 40, b: 40 }
        };
        window.Plotly.newPlot('fairnessChart', data, layout);
    }
}

function initConsentManagement() {
    const consentList = document.getElementById('consentList');
    if (!consentList) {
        return;
    }

    fetch('/api/consents')
        .then(function (response) { return response.json(); })
        .then(function (consents) {
            if (!Array.isArray(consents) || !consents.length) {
                consentList.innerHTML = '<p class="text-muted mb-0">No consent records found.</p>';
                return;
            }
            consentList.innerHTML = '';
            consents.forEach(function (c) {
                const wrapper = document.createElement('div');
                wrapper.className = 'consent-item mb-3';
                const row = document.createElement('div');
                row.className = 'd-flex justify-content-between align-items-center';
                const left = document.createElement('div');
                const title = document.createElement('h6');
                title.className = 'mb-1';
                title.textContent = c.consent_type || '';
                const subtitle = document.createElement('small');
                subtitle.className = 'text-muted';
                subtitle.textContent = c.purpose_description || '';
                left.appendChild(title);
                left.appendChild(subtitle);
                const right = document.createElement('div');
                right.className = 'form-check form-switch';
                const input = document.createElement('input');
                input.className = 'form-check-input';
                input.type = 'checkbox';
                input.checked = !!c.is_granted;
                input.dataset.consentId = c.id;
                input.addEventListener('change', function (e) {
                    updateConsentToggle(e.target);
                });
                right.appendChild(input);
                row.appendChild(left);
                row.appendChild(right);
                wrapper.appendChild(row);
                consentList.appendChild(wrapper);
            });
        })
        .catch(function (error) {
            console.error('Failed to load consents', error);
            consentList.innerHTML = '<p class="text-danger mb-0">Failed to load consents.</p>';
        });
}

function updateConsentToggle(input) {
    const consentId = input.dataset.consentId;
    if (!consentId) {
        return;
    }
    fetch('/api/consent/update', {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            consentId: consentId,
            granted: input.checked
        })
    })
        .then(function (response) { return response.json(); })
        .then(function () {})
        .catch(function (error) {
            console.error('Failed to update consent', error);
            input.checked = !input.checked;
        });
}

function initBiasAlerts(role) {
    const container = document.getElementById('biasAlertsList');
    if (!container) {
        return;
    }

    if (role === 'admin' || role === 'compliance_officer') {
        fetch('/api/bias/alerts')
            .then(function (response) { return response.json(); })
            .then(function (alerts) {
                if (!Array.isArray(alerts) || !alerts.length) {
                    container.innerHTML = '<p class="text-muted mb-0">No active bias alerts.</p>';
                    return;
                }
                container.innerHTML = '';
                alerts.forEach(function (a) {
                    const alertDiv = document.createElement('div');
                    alertDiv.className = 'alert alert-warning mb-2';
                    alertDiv.textContent = (a.title || 'Bias Alert') + ' - ' + (a.description || '');
                    container.appendChild(alertDiv);
                });
            })
            .catch(function (error) {
                console.error('Failed to load bias alerts', error);
                container.innerHTML = '<p class="text-danger mb-0">Failed to load bias alerts.</p>';
            });
    } else {
        container.innerHTML = '<p class="text-muted mb-0">No critical bias alerts affecting your account.</p>';
    }
}

function viewAuditLogs() {
    const tableBody = document.getElementById('auditLogsTable');
    if (!tableBody) {
        return;
    }

    fetch('/api/audit/logs?limit=100')
        .then(function (response) { return response.json(); })
        .then(function (logs) {
            if (!Array.isArray(logs) || !logs.length) {
                tableBody.innerHTML = '<tr><td colspan="6" class="text-center text-muted">No audit logs found</td></tr>';
                return;
            }
            tableBody.innerHTML = '';
            logs.forEach(function (log) {
                const tr = document.createElement('tr');
                tr.innerHTML = '' +
                    '<td>' + (log.created_at || '') + '</td>' +
                    '<td>' + (log.user_email || '') + '</td>' +
                    '<td>' + (log.action_type || '') + '</td>' +
                    '<td>' + (log.resource_type || '') + '</td>' +
                    '<td>' + (log.status || '') + '</td>' +
                    '<td>' + JSON.stringify(log.action_details || {}) + '</td>';
                tableBody.appendChild(tr);
            });
            const modalElement = document.getElementById('auditLogsModal');
            if (modalElement && window.bootstrap) {
                new window.bootstrap.Modal(modalElement).show();
            }
        })
        .catch(function (error) {
            console.error('Failed to load audit logs', error);
        });
}

function viewModelPerformance() {
    fetch('/api/models/performance')
        .then(function (response) { return response.json(); })
        .then(function (data) {
            console.log('Model performance', data);
        })
        .catch(function (error) {
            console.error('Failed to load model performance', error);
        });
}
