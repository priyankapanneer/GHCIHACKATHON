// TrustAI Frontend JavaScript
// Main application logic for form validation, API calls, and UI interactions

class TrustAI {
    constructor() {
        this.apiBase = '/api';
        this.token = localStorage.getItem('trustai_token');
        this.user = JSON.parse(localStorage.getItem('trustai_user') || '{}');
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.setupFormValidation();
        this.checkAuthStatus();
        this.initializeUI();
    }

    // API Communication
    async apiCall(endpoint, options = {}) {
        const url = `${this.apiBase}${endpoint}`;
        const config = {
            headers: {
                'Content-Type': 'application/json',
                ...(this.token && { 'Authorization': `Bearer ${this.token}` })
            },
            ...options
        };

        try {
            const response = await fetch(url, config);
            const data = await response.json();
            
            if (!response.ok) {
                throw new Error(data.message || 'API request failed');
            }
            
            return data;
        } catch (error) {
            console.error('API Error:', error);
            this.showAlert(error.message, 'danger');
            throw error;
        }
    }

    // Authentication
    async login(email, password) {
        try {
            const data = await this.apiCall('/auth/login', {
                method: 'POST',
                body: JSON.stringify({ email, password })
            });

            this.token = data.token;
            this.user = data.user;
            
            localStorage.setItem('trustai_token', this.token);
            localStorage.setItem('trustai_user', JSON.stringify(this.user));

            this.showAlert('Login successful!', 'success');
            this.redirectBasedOnRole();
        } catch (error) {
            this.showAlert('Login failed: ' + error.message, 'danger');
        }
    }

    async register(userData) {
        try {
            await this.apiCall('/auth/register', {
                method: 'POST',
                body: JSON.stringify(userData)
            });

            this.showAlert('Registration successful! Please login.', 'success');
            setTimeout(() => {
                window.location.href = '/login';
            }, 2000);
        } catch (error) {
            this.showAlert('Registration failed: ' + error.message, 'danger');
        }
    }

    async logout() {
        try {
            await this.apiCall('/auth/logout', { method: 'POST' });
        } catch (e) {
            // Ignore errors, proceed to clear session
        }
        localStorage.removeItem('trustai_token');
        localStorage.removeItem('trustai_user');
        this.token = null;
        this.user = {};
        window.location.href = '/login';
    }

    checkAuthStatus() {
        const protectedPages = ['/dashboard', '/customer_dashboard', '/admin_panel'];
        const currentPage = window.location.pathname;

        if (protectedPages.includes(currentPage) && !this.token) {
            window.location.href = '/login';
            return;
        }

        if (this.token && this.user.name) {
            this.updateUIForAuthenticatedUser();
        }
    }

    redirectBasedOnRole() {
        window.location.href = '/dashboard';
    }

    // Form Validation
    setupFormValidation() {
        // Login form
        const loginForm = document.getElementById('loginForm');
        if (loginForm) {
            loginForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.handleLogin();
            });
        }

        // Registration form
        const registerForm = document.getElementById('registerForm');
        if (registerForm) {
            registerForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.handleRegistration();
            });
        }
    }

    handleLogin() {
        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;

        if (!this.validateEmail(email)) {
            this.showAlert('Please enter a valid email address', 'danger');
            return;
        }

        if (password.length < 6) {
            this.showAlert('Password must be at least 6 characters', 'danger');
            return;
        }

        this.showLoading();
        this.login(email, password).finally(() => {
            this.hideLoading();
        });
    }

    handleRegistration() {
        const formData = {
            firstName: document.getElementById('firstName').value,
            lastName: document.getElementById('lastName').value,
            email: document.getElementById('email').value,
            role: document.getElementById('role').value,
            password: document.getElementById('password').value,
            confirmPassword: document.getElementById('confirmPassword').value,
            department: document.getElementById('department').value,
            terms: document.getElementById('terms').checked,
            dataConsent: document.getElementById('dataConsent').checked
        };

        if (!this.validateRegistration(formData)) {
            return;
        }

        this.showLoading();
        this.register(formData).finally(() => {
            this.hideLoading();
        });
    }

    validateEmail(email) {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(email);
    }

    validateRegistration(data) {
        if (!data.firstName || !data.lastName) {
            this.showAlert('Please enter your full name', 'danger');
            return false;
        }

        if (!this.validateEmail(data.email)) {
            this.showAlert('Please enter a valid email address', 'danger');
            return false;
        }

        if (!data.role) {
            this.showAlert('Please select your account type', 'danger');
            return false;
        }

        if (data.password.length < 6) {
            this.showAlert('Password must be at least 6 characters', 'danger');
            return false;
        }

        if (data.password !== data.confirmPassword) {
            this.showAlert('Passwords do not match', 'danger');
            return false;
        }

        if (!data.terms) {
            this.showAlert('Please accept the terms and conditions', 'danger');
            return false;
        }

        return true;
    }

    // UI Management
    setupEventListeners() {
        // Consent toggles
        document.querySelectorAll('input[type="checkbox"][id^="consent"]').forEach(checkbox => {
            checkbox.addEventListener('change', (e) => {
                this.updateConsent(e.target.id, e.target.checked);
            });
        });

        // Auto-refresh for dashboard data
        if (window.location.pathname.includes('dashboard') || 
            window.location.pathname.includes('admin_panel')) {
            this.startDashboardRefresh();
        }
    }

    updateUIForAuthenticatedUser() {
        const userNameElement = document.getElementById('userName');
        if (userNameElement && this.user.name) {
            userNameElement.textContent = `${this.user.firstName} ${this.user.lastName}`;
        }
    }

    initializeUI() {
        // Add fade-in animation to cards
        document.querySelectorAll('.card').forEach((card, index) => {
            card.style.animationDelay = `${index * 0.1}s`;
            card.classList.add('fade-in');
        });

        // Initialize tooltips
        const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
        tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl);
        });
    }

    startDashboardRefresh() {
        // Refresh dashboard data every 30 seconds
        setInterval(() => {
            this.refreshDashboardData();
        }, 30000);
    }

    async refreshDashboardData() {
        try {
            // Update stats
            await this.updateDashboardStats();
            // Update recent decisions
            await this.updateRecentDecisions();
            // Update fairness metrics
            await this.updateFairnessMetrics();
        } catch (error) {
            console.error('Dashboard refresh failed:', error);
        }
    }

    async updateDashboardStats() {
        try {
            const stats = await this.apiCall('/dashboard/stats');
            
            // Update stat cards with animation
            this.animateValue('decisionCount', stats.decisions || 0);
            this.animateValue('consentCount', stats.consents || 0);
            this.animateValue('fairnessScore', stats.fairnessScore || 0);
            this.animateValue('biasAlerts', stats.biasAlerts || 0);
        } catch (error) {
            console.error('Failed to update dashboard stats:', error);
        }
    }

    animateValue(elementId, endValue) {
        const element = document.getElementById(elementId);
        if (!element) return;

        const startValue = parseInt(element.textContent) || 0;
        const duration = 1000;
        const startTime = performance.now();

        const updateValue = (currentTime) => {
            const elapsed = currentTime - startTime;
            const progress = Math.min(elapsed / duration, 1);
            const currentValue = Math.floor(startValue + (endValue - startValue) * progress);
            
            element.textContent = currentValue;

            if (progress < 1) {
                requestAnimationFrame(updateValue);
            }
        };

        requestAnimationFrame(updateValue);
    }

    // Consent Management
    async updateConsent(consentId, granted) {
        try {
            await this.apiCall('/consent/update', {
                method: 'PUT',
                body: JSON.stringify({ consentId, granted })
            });

            this.showAlert('Consent updated successfully', 'success');
        } catch (error) {
            this.showAlert('Failed to update consent: ' + error.message, 'danger');
            // Revert checkbox state
            document.getElementById(consentId).checked = !granted;
        }
    }

    // AI Decision Management
    async getDecisionExplanation(decisionId) {
        try {
            const explanation = await this.apiCall(`/decisions/${decisionId}/explain`);
            return explanation;
        } catch (error) {
            console.error('Failed to get explanation:', error);
            throw error;
        }
    }

    // Bias Monitoring
    async getBiasMetrics() {
        try {
            const metrics = await this.apiCall('/bias/metrics');
            return metrics;
        } catch (error) {
            console.error('Failed to get bias metrics:', error);
            throw error;
        }
    }

    // Audit Log Management
    async getAuditLogs(limit = 50) {
        try {
            const logs = await this.apiCall(`/audit/logs?limit=${limit}`);
            return logs;
        } catch (error) {
            console.error('Failed to get audit logs:', error);
            throw error;
        }
    }

    // Utility Functions
    showAlert(message, type = 'info') {
        const alertContainer = document.getElementById('alertMessage') || 
                              document.getElementById('successMessage') ||
                              this.createAlertContainer();

        if (alertContainer) {
            alertContainer.className = `alert alert-${type} alert-dismissible fade show`;
            alertContainer.textContent = message;
            alertContainer.classList.remove('d-none');

            // Auto-hide after 5 seconds
            setTimeout(() => {
                alertContainer.classList.add('d-none');
            }, 5000);
        }
    }

    createAlertContainer() {
        const container = document.createElement('div');
        container.id = 'dynamicAlert';
        container.className = 'alert alert-info alert-dismissible fade show position-fixed';
        container.style.top = '20px';
        container.style.right = '20px';
        container.style.zIndex = '9999';
        document.body.appendChild(container);
        return container;
    }

    showLoading() {
        const buttons = document.querySelectorAll('button[type="submit"]');
        buttons.forEach(button => {
            button.disabled = true;
            button.innerHTML = '<span class="loading-spinner"></span> Processing...';
        });
    }

    hideLoading() {
        const buttons = document.querySelectorAll('button[type="submit"]');
        buttons.forEach(button => {
            button.disabled = false;
            button.innerHTML = button.getAttribute('data-original-text') || 'Submit';
        });
    }

    // Data Export
    async exportData(format = 'json') {
        try {
            // Data export handlers
            if (format === 'governance_pdf') {
                // Generate Governance PDF client-side using jsPDF to avoid backend PDF deps
                this.showAlert('Generating Governance PDF...', 'info');
                await this._ensureJsPdf();
                try {
                    const { jsPDF } = window.jspdf || window;
                    const doc = new jsPDF({ unit: 'pt', format: 'letter' });
                    const title = 'Governance Report - AI Review Board';
                    doc.setFontSize(18);
                    doc.text(title, 40, 60);
                    doc.setFontSize(10);
                    const timestamp = new Date().toLocaleString();
                    doc.text(`Generated: ${timestamp}`, 40, 80);

                    // Fetch current review tickets to include
                    let tickets = [];
                    try {
                        const resp = await fetch('/api/profile/corrections');
                        if (resp.ok) tickets = await resp.json();
                    } catch (e) {
                        // ignore - include placeholder
                    }

                    let y = 110;
                    if (!tickets || !tickets.length) {
                        doc.text('No review tickets available.', 40, y);
                    } else {
                        tickets.forEach((t, idx) => {
                            const header = `${idx + 1}. ${t.id || 'TICKET-' + (idx + 1)} - ${t.status || 'pending'}`;
                            doc.text(header, 40, y);
                            y += 14;
                            const desc = (t.description || t.reason || '').replace(/\s+/g, ' ');
                            const lines = doc.splitTextToSize(desc || 'No description provided.', 500);
                            doc.text(lines, 60, y);
                            y += lines.length * 12 + 8;
                            // paginate if needed
                            if (y > 700) {
                                doc.addPage();
                                y = 40;
                            }
                        });
                    }

                    // Save PDF
                    doc.save(`governance_report_${Date.now()}.pdf`);
                    this.showAlert('Governance PDF generated.', 'success');
                } catch (err) {
                    console.error('PDF generation failed', err);
                    this.showAlert('Failed to generate PDF: ' + err.message, 'danger');
                }

            } else if (format === 'consent_csv') {
                this.showAlert('Downloading Consent CSV...', 'info');
                this.downloadFile('user_id,consent_type,is_granted\n1,credit_scoring,true', 'consent_export.csv', 'text/csv');
            } else if (format === 'ops_json') {
                this.showAlert('Downloading Operations JSON...', 'info');
                const opsData = {
                    system_status: 'operational',
                    active_models: ['loan_approval', 'fraud_detection']
                };
                this.downloadFile(JSON.stringify(opsData, null, 2), 'operations_data.json', 'application/json');
            } else {
                const data = await this.apiCall(`/export?format=${format}`);
                this.downloadFile(JSON.stringify(data, null, 2), `trustai_export_${Date.now()}.${format}`, 'application/json');
            }
        } catch (error) {
            this.showAlert('Export failed: ' + error.message, 'danger');
        }
    }

    async _ensureJsPdf() {
        if (window.jspdf || window.jsPDF) return;
        return new Promise((resolve, reject) => {
            const script = document.createElement('script');
            script.src = 'https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js';
            script.onload = () => {
                // some UMD builds attach to window.jspdf
                if (window.jspdf || window.jsPDF) return resolve();
                // try a short timeout to allow UMD to attach
                setTimeout(() => {
                    if (window.jspdf || window.jsPDF) return resolve();
                    reject(new Error('jsPDF failed to load'));
                }, 200);
            };
            script.onerror = () => reject(new Error('Failed to load jsPDF from CDN'));
            document.head.appendChild(script);
        });
    }

    downloadFile(data, filename, type) {
        const blob = new Blob([data], { type });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);
    }

    // Real-time Updates (WebSocket placeholder)
    setupWebSocket() {
        // This would be implemented with actual WebSocket connection
        // For now, using polling as fallback
        console.log('WebSocket connection would be established here');
    }

    // Security Functions
    sanitizeInput(input) {
        const div = document.createElement('div');
        div.textContent = input;
        return div.innerHTML;
    }

    validateCSRFToken() {
        // CSRF token validation would go here
        return true;
    }

    // Performance Monitoring
    logPerformance(metric, value) {
        // Log performance metrics for monitoring
        console.log(`Performance: ${metric} = ${value}`);
    }

    // Error Reporting
    reportError(error, context = {}) {
        // Error reporting implementation
        console.error('Error reported:', { error, context });
    }
}

// Global functions for HTML onclick handlers
function logout() {
    if (window.trustai) {
        window.trustai.logout();
    }
}

function viewExplanation(decisionId) {
    if (window.trustai) {
        window.trustai.getDecisionExplanation(decisionId)
            .then(explanation => {
                // Update modal content with explanation
                document.getElementById('explanationContent').innerHTML = 
                    `<pre>${JSON.stringify(explanation, null, 2)}</pre>`;
                // Show explanation modal
                const modalEl = document.getElementById('explanationModal');
                if (modalEl && window.bootstrap) {
                    const modal = bootstrap.Modal.getOrCreateInstance
                        ? bootstrap.Modal.getOrCreateInstance(modalEl)
                        : new bootstrap.Modal(modalEl);
                    modal.show();
                }
            })
            .catch(error => {
                console.error('Failed to load explanation:', error);
            });
    }
}

function investigateBias(alertId) {
    console.log('Investigating bias alert:', alertId);
    // Implementation for bias investigation
}

function retrainModel(modelId) {
    if (confirm('Are you sure you want to retrain this model?')) {
        console.log('Retraining model:', modelId);
        // Implementation for model retraining
    }
}

function runBiasAudit() {
    console.log('Running bias audit...');
    // Implementation for bias audit
}

function generateReport() {
    if (window.trustai) {
        window.trustai.exportData('json');
    }
}

function emergencyShutdown() {
    if (confirm('EMERGENCY SHUTDOWN: Are you sure? This will stop all AI systems.')) {
        console.log('Emergency shutdown initiated');
        // Implementation for emergency shutdown
    }
}

function exportData() {
    if (window.trustai) {
        window.trustai.exportData('csv');
    }
}

function scheduleMaintenance() {
    console.log('Opening maintenance scheduler...');
    // Implementation for maintenance scheduling
}

function backupSystem() {
    console.log('Initiating system backup...');
    // Implementation for system backup
}

function viewLogDetails(logId) {
    console.log('Viewing log details:', logId);
    // Implementation for viewing log details
}

function dismissAlert(alertId) {
    console.log('Dismissing alert:', alertId);
    // Implementation for dismissing alerts
}

// Initialize the application
document.addEventListener('DOMContentLoaded', () => {
    window.trustai = new TrustAI();
    
    // Store original button text for loading states
    document.querySelectorAll('button[type="submit"]').forEach(button => {
        button.setAttribute('data-original-text', button.innerHTML);
    });
});

// Export for module usage
if (typeof module !== 'undefined' && module.exports) {
    module.exports = TrustAI;
}
